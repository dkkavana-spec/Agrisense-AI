@echo off
setlocal enabledelayedexpansion
title LeafMind — AI Plant Disease Diagnosis

echo.
echo  ==========================================
echo   LeafMind ^| AI Plant Disease Diagnosis
echo  ==========================================
echo.

:: ── Check Node.js ────────────────────────────────────────────
where node >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Node.js is not installed.
    echo         Download it from: https://nodejs.org
    pause
    exit /b 1
)

:: ── Check Python ─────────────────────────────────────────────
where python >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not installed.
    echo         Download it from: https://python.org
    pause
    exit /b 1
)

:: ── Check .env file ──────────────────────────────────────────
if not exist backend\.env (
    if exist backend\.env.example (
        copy backend\.env.example backend\.env >nul
        echo [SETUP] Created backend\.env from .env.example
        echo         ^> Open backend\.env and add your OPENAI_API_KEY
        echo.
        notepad backend\.env
        echo [INFO]  Close Notepad and press any key to continue...
        pause >nul
    )
)

:: ── Install backend dependencies ─────────────────────────────
if not exist backend\node_modules (
    echo [1/3] Installing backend dependencies...
    cd backend
    call npm install
    cd ..
) else (
    echo [1/3] Backend dependencies already installed.
)

:: ── Install frontend dependencies ────────────────────────────
echo [2/3] Installing Python dependencies...
pip install -r frontend\requirements.txt --quiet

:: ── Start backend ─────────────────────────────────────────────
echo [3/3] Starting services...
echo.
echo  React web app  →  http://localhost:3001
echo  AgroBot API    →  http://localhost:3001/api
echo  Streamlit UI   →  http://localhost:8501
echo.
echo  Press Ctrl+C in each window to stop.
echo.

:: Start backend in a new window
start "LeafMind Backend" cmd /k "cd /d %~dp0backend && node src/index.js"

:: Wait a moment for backend to start
timeout /t 3 /nobreak >nul

:: Start Streamlit in a new window
start "LeafMind Streamlit" cmd /k "cd /d %~dp0frontend && python -m streamlit run app.py --server.port 8501"

:: Open browser
timeout /t 4 /nobreak >nul
start http://localhost:3001

echo.
echo  [OK] All services started in separate windows.
echo       Close those windows to stop the servers.
echo.
pause
