const { useState, useEffect, useRef, useCallback } = React;

// ── Constants ────────────────────────────────────────────────────────────────
const LANGUAGES = [
  { code: "en", label: "English" },
  { code: "hi", label: "हिंदी" },
  { code: "kn", label: "ಕನ್ನಡ" },
  { code: "te", label: "తెలుగు" },
  { code: "ta", label: "தமிழ்" },
  { code: "mr", label: "मराठी" },
  { code: "bn", label: "বাংলা" },
  { code: "gu", label: "ગુજરાતી" },
  { code: "pa", label: "ਪੰਜਾਬੀ" },
];

const CROPS = ["rice","wheat","maize","tomato","potato","cotton","soybean","sugarcane","other"];

const SUGGESTED = {
  en: ["What are symptoms of rice blast?","How to treat wheat rust?","Control aphids organically?","Best fertilizer for tomato?"],
  hi: ["धान के ब्लास्ट के लक्षण?","गेहूं रस्ट का उपचार?","कीड़े जैविक तरीके से कैसे रोकें?","टमाटर के लिए खाद?"],
  kn: ["ಭತ್ತದ ಬ್ಲಾಸ್ಟ್ ಲಕ್ಷಣ?","ಗೋಧಿ ತುಕ್ಕು ಚಿಕಿತ್ಸೆ?","ಮಾಹು ಜೈವಿಕ ನಿಯಂತ್ರಣ?","ಟೊಮೇಟೊ ಗೊಬ್ಬರ?"],
  te: ["వరి బ్లాస్ట్ లక్షణాలు?","గోధుమ తుప్పు చికిత్స?","అఫిడ్ సేంద్రియ నియంత్రణ?","టమాటా ఎరువు?"],
  ta: ["நெல் வெடிப்பு அறிகுறிகள்?","கோதுமை துரு சிகிச்சை?","அசுவினி இயற்கை கட்டுப்பாடு?","தக்காளி உரம்?"],
  mr: ["भात ब्लास्ट लक्षणे?","गव्हाचा गंज उपचार?","मावा जैविक नियंत्रण?","टोमॅटो खत?"],
  bn: ["ধান ব্লাস্ট লক্ষণ?","গম মরিচা চিকিৎসা?","এফিড জৈব নিয়ন্ত্রণ?","টমেটো সার?"],
  gu: ["ડાંગર બ્લાસ્ટ લક્ષણ?","ઘઉં ગેરુ સારવાર?","માહૂ જૈવ નિયંત્રણ?","ટામેટા ખાતર?"],
  pa: ["ਝੋਨਾ ਬਲਾਸਟ ਲੱਛਣ?","ਕਣਕ ਗੇਰੂ ਇਲਾਜ?","ਮਾਹੂ ਜੈਵਿਕ ਕੰਟਰੋਲ?","ਟਮਾਟੇ ਦੀ ਖਾਦ?"],
};

// ── Styles ───────────────────────────────────────────────────────────────────
const css = `
  .app { display:flex; flex-direction:column; min-height:100vh; }
  .header { position:sticky; top:0; z-index:30; background:rgba(250,249,245,.85); backdrop-filter:blur(12px); border-bottom:1px solid var(--border); }
  .header-inner { max-width:1100px; margin:0 auto; padding:.75rem 1.5rem; display:flex; align-items:center; justify-content:space-between; gap:1rem; }
  .logo { display:flex; align-items:center; gap:.5rem; text-decoration:none; color:var(--fg); }
  .logo-icon { width:2rem; height:2rem; background:var(--primary); border-radius:.5rem; display:grid; place-items:center; color:var(--primary-fg); font-size:1rem; }
  .logo-text { font-family:'Fraunces',serif; font-size:1.15rem; font-weight:600; }
  .header-right { display:flex; align-items:center; gap:.75rem; }
  .lang-select { border:1px solid var(--border); background:var(--card); border-radius:.5rem; padding:.35rem .6rem; font-size:.8rem; }
  .nav { display:flex; gap:.25rem; }
  .nav-btn { background:none; border:none; border-radius:.6rem; padding:.4rem .9rem; font-size:.85rem; font-weight:500; color:var(--muted); transition:all .15s; }
  .nav-btn.active { background:var(--primary); color:var(--primary-fg); }
  .nav-btn:hover:not(.active) { background:var(--secondary); }
  .main { max-width:1100px; margin:0 auto; padding:2rem 1.5rem; width:100%; flex:1; }

  /* Cards */
  .card { background:var(--card); border:1px solid var(--border); border-radius:var(--radius); padding:1.5rem; box-shadow:var(--shadow); }
  .hero { background:linear-gradient(135deg,#1a4731,#2d6a4f); color:white; border:none; border-radius:1.5rem; padding:2rem; margin-bottom:1.5rem; }
  .hero h1 { color:white; font-size:2rem; margin-bottom:.4rem; }
  .hero p { color:rgba(255,255,255,.8); }
  .stats-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:1rem; margin-bottom:1.5rem; }
  .stat-card { background:var(--card); border:1px solid var(--border); border-radius:var(--radius); padding:1.25rem; box-shadow:var(--shadow); }
  .stat-label { font-size:.7rem; text-transform:uppercase; letter-spacing:.06em; color:var(--muted); display:flex; align-items:center; gap:.4rem; }
  .stat-value { font-family:'Fraunces',serif; font-size:2rem; font-weight:600; margin-top:.25rem; }

  /* Buttons */
  .btn { display:inline-flex; align-items:center; gap:.4rem; border:none; border-radius:.75rem; padding:.6rem 1.25rem; font-size:.875rem; font-weight:600; cursor:pointer; transition:all .15s; }
  .btn-primary { background:linear-gradient(135deg,#1a4731,#2d6a4f); color:white; box-shadow:var(--glow); }
  .btn-primary:hover { opacity:.9; transform:translateY(-1px); }
  .btn-primary:disabled { opacity:.5; cursor:not-allowed; transform:none; }
  .btn-outline { background:var(--card); border:1px solid var(--border); color:var(--fg); }
  .btn-outline:hover { background:var(--secondary); }
  .btn-ghost { background:none; border:none; color:var(--muted); padding:.4rem .75rem; }
  .btn-ghost:hover { background:var(--secondary); color:var(--fg); }
  .btn-danger { background:#fee2e2; color:var(--destructive); border:1px solid #fca5a5; }
  .btn-danger:hover { background:#fecaca; }
  .btn-voice { background:var(--secondary); border:2px solid var(--primary); color:var(--primary); border-radius:50%; width:2.75rem; height:2.75rem; font-size:1.1rem; display:grid; place-items:center; flex-shrink:0; }
  .btn-voice.recording { background:var(--destructive); border-color:var(--destructive); color:white; animation:pulse 1s infinite; }
  @keyframes pulse { 0%,100%{box-shadow:0 0 0 0 rgba(220,38,38,.4)} 50%{box-shadow:0 0 0 8px rgba(220,38,38,0)} }

  /* Form */
  .form-group { margin-bottom:1rem; }
  .form-label { display:block; font-size:.8rem; font-weight:600; margin-bottom:.35rem; color:var(--fg); }
  .form-input { width:100%; border:1px solid var(--border); background:var(--bg); border-radius:.6rem; padding:.6rem .85rem; font-size:.9rem; }
  .form-input:focus { outline:none; border-color:var(--primary); box-shadow:0 0 0 3px rgba(26,71,49,.12); }
  .form-select { width:100%; border:1px solid var(--border); background:var(--bg); border-radius:.6rem; padding:.6rem .85rem; font-size:.9rem; }
  .form-textarea { width:100%; border:1px solid var(--border); background:var(--bg); border-radius:.6rem; padding:.6rem .85rem; font-size:.9rem; resize:none; }
  .form-textarea:focus { outline:none; border-color:var(--primary); box-shadow:0 0 0 3px rgba(26,71,49,.12); }

  /* Upload */
  .upload-zone { border:2px dashed var(--border); border-radius:var(--radius); background:var(--secondary); aspect-ratio:4/3; display:grid; place-items:center; text-align:center; cursor:pointer; transition:border-color .2s; overflow:hidden; position:relative; }
  .upload-zone:hover { border-color:var(--primary); }
  .upload-zone img { width:100%; height:100%; object-fit:cover; }
  .upload-text { padding:2rem; }

  /* Diagnosis result */
  .result-header { background:linear-gradient(135deg,#1a4731,#2d6a4f); color:white; border-radius:var(--radius) var(--radius) 0 0; padding:1.5rem; }
  .result-header h2 { color:white; font-size:1.75rem; margin:.35rem 0; }
  .result-body { padding:1.5rem; border:1px solid var(--border); border-top:none; border-radius:0 0 var(--radius) var(--radius); background:var(--card); }
  .section-title { font-size:.7rem; font-weight:700; text-transform:uppercase; letter-spacing:.07em; color:var(--muted); margin-bottom:.5rem; }
  .section-body { font-size:.9rem; line-height:1.7; white-space:pre-line; }
  .info-panels { display:grid; grid-template-columns:1fr 1fr; gap:1rem; margin-top:1rem; }

  /* Severity badges */
  .badge { display:inline-block; border-radius:9999px; padding:.2rem .7rem; font-size:.7rem; font-weight:700; text-transform:uppercase; letter-spacing:.05em; }
  .badge-none,.badge-mild { background:#dcfce7; color:#15803d; }
  .badge-moderate { background:#fef9c3; color:#854d0e; }
  .badge-severe { background:#fee2e2; color:#dc2626; }

  /* Chat */
  .chat-wrap { display:flex; flex-direction:column; height:calc(100vh - 12rem); }
  .chat-messages { flex:1; overflow-y:auto; padding:1rem; display:flex; flex-direction:column; gap:.75rem; background:var(--card); border:1px solid var(--border); border-radius:var(--radius) var(--radius) 0 0; }
  .chat-msg { display:flex; gap:.65rem; align-items:flex-start; }
  .chat-msg.user { flex-direction:row-reverse; }
  .chat-avatar { width:2rem; height:2rem; border-radius:50%; display:grid; place-items:center; font-size:.8rem; flex-shrink:0; }
  .chat-avatar.bot { background:var(--secondary); border:1px solid var(--border); color:var(--primary); }
  .chat-avatar.user { background:var(--primary); color:white; }
  .chat-bubble { max-width:80%; padding:.75rem 1rem; border-radius:1rem; font-size:.875rem; line-height:1.6; white-space:pre-wrap; }
  .chat-bubble.bot { background:var(--secondary); border-radius:1rem 1rem 1rem .25rem; }
  .chat-bubble.user { background:linear-gradient(135deg,#1a4731,#2d6a4f); color:white; border-radius:1rem 1rem .25rem 1rem; }
  .chat-time { font-size:.65rem; color:var(--muted); margin-top:.25rem; padding:0 .25rem; }
  .chat-input-bar { border:1px solid var(--border); border-top:none; border-radius:0 0 var(--radius) var(--radius); padding:.75rem; background:var(--card); display:flex; gap:.5rem; align-items:flex-end; }
  .chat-textarea { flex:1; border:1px solid var(--border); background:var(--bg); border-radius:.6rem; padding:.6rem .85rem; font-size:.875rem; resize:none; }
  .chat-textarea:focus { outline:none; border-color:var(--primary); }
  .chat-hint { font-size:.7rem; color:var(--muted); padding:.4rem .5rem; }

  /* Suggestions */
  .suggestions { display:grid; grid-template-columns:1fr 1fr; gap:.5rem; margin-bottom:1rem; }
  .suggestion-btn { background:var(--secondary); border:1px solid var(--border); border-radius:.75rem; padding:.6rem .85rem; font-size:.8rem; text-align:left; color:var(--fg); transition:all .15s; }
  .suggestion-btn:hover { border-color:var(--primary); background:rgba(26,71,49,.05); }

  /* History */
  .history-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(280px,1fr)); gap:1rem; }
  .history-card { background:var(--card); border:1px solid var(--border); border-radius:var(--radius); overflow:hidden; box-shadow:var(--shadow); cursor:pointer; transition:transform .15s; }
  .history-card:hover { transform:translateY(-2px); }
  .history-img { aspect-ratio:4/3; background:var(--secondary); display:grid; place-items:center; overflow:hidden; }
  .history-img img { width:100%; height:100%; object-fit:cover; }
  .history-body { padding:1rem; }
  .history-crop { font-size:.7rem; text-transform:uppercase; color:var(--muted); }
  .history-name { font-family:'Fraunces',serif; font-size:1.1rem; font-weight:600; margin:.2rem 0; }
  .history-date { font-size:.7rem; color:var(--muted); }
  .modal-overlay { position:fixed; inset:0; background:rgba(0,0,0,.45); z-index:50; display:grid; place-items:center; padding:1rem; backdrop-filter:blur(4px); }
  .modal { background:var(--card); border-radius:1.25rem; max-width:660px; width:100%; max-height:90vh; overflow-y:auto; box-shadow:var(--glow); }
  .modal-header { padding:1.5rem; background:linear-gradient(135deg,#1a4731,#2d6a4f); color:white; border-radius:1.25rem 1.25rem 0 0; }
  .modal-body { padding:1.5rem; }

  /* Toast */
  .toast { position:fixed; top:1rem; right:1rem; z-index:100; background:var(--primary); color:white; padding:.75rem 1.25rem; border-radius:.75rem; font-size:.875rem; box-shadow:var(--glow); animation:slideIn .25s ease; }
  @keyframes slideIn { from{opacity:0;transform:translateX(100%)} to{opacity:1;transform:translateX(0)} }

  /* Thinking dots */
  .typing { display:flex; gap:.3rem; padding:.5rem; }
  .typing span { width:.5rem; height:.5rem; background:var(--muted); border-radius:50%; animation:bounce .8s infinite; }
  .typing span:nth-child(2) { animation-delay:.15s; }
  .typing span:nth-child(3) { animation-delay:.3s; }
  @keyframes bounce { 0%,80%,100%{transform:translateY(0)} 40%{transform:translateY(-6px)} }

  /* Voice indicator */
  .voice-bar { display:flex; align-items:center; gap:.75rem; background:#fff0f0; border:1px solid #fca5a5; border-radius:.75rem; padding:.75rem 1rem; margin-bottom:.75rem; font-size:.85rem; color:var(--destructive); }

  /* Responsive */
  @media(max-width:640px) {
    .stats-grid { grid-template-columns:1fr 1fr; }
    .info-panels { grid-template-columns:1fr; }
    .suggestions { grid-template-columns:1fr; }
    .header-right .nav { display:none; }
    .main { padding:1rem; }
  }
`;

// ── Utilities ─────────────────────────────────────────────────────────────────
function Toast({ msg, onClose }) {
  useEffect(() => { const t = setTimeout(onClose, 3500); return () => clearTimeout(t); }, []);
  return <div className="toast">{msg}</div>;
}

function Spinner() {
  return <div style={{display:"flex",alignItems:"center",gap:".5rem",color:"var(--muted)",fontSize:".875rem"}}>
    <div style={{width:"1rem",height:"1rem",borderRadius:"50%",border:"2px solid var(--border)",borderTopColor:"var(--primary)",animation:"spin .7s linear infinite"}} />
    Thinking…
    <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
  </div>;
}

function SeverityBadge({ severity }) {
  const s = severity || "none";
  return <span className={`badge badge-${s}`}>Severity: {s.toUpperCase()}</span>;
}

// ── useVoiceInput hook ────────────────────────────────────────────────────────
function useVoiceInput(onResult) {
  const [recording, setRecording] = useState(false);
  const [supported, setSupported] = useState(false);
  const recRef = useRef(null);

  useEffect(() => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    setSupported(!!SR);
  }, []);

  const start = useCallback((lang) => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return;

    // Map our lang codes to BCP-47 locales
    const localeMap = {
      en: "en-IN", hi: "hi-IN", kn: "kn-IN", te: "te-IN",
      ta: "ta-IN", mr: "mr-IN", bn: "bn-IN", gu: "gu-IN", pa: "pa-IN",
    };

    const rec = new SR();
    rec.lang = localeMap[lang] || "en-IN";
    rec.interimResults = false;
    rec.maxAlternatives = 1;
    rec.continuous = false;

    rec.onresult = (e) => {
      const transcript = e.results[0][0].transcript;
      onResult(transcript);
    };
    rec.onerror = () => setRecording(false);
    rec.onend = () => setRecording(false);

    rec.start();
    recRef.current = rec;
    setRecording(true);
  }, [onResult]);

  const stop = useCallback(() => {
    recRef.current?.stop();
    setRecording(false);
  }, []);

  return { recording, supported, start, stop };
}

// ── Main App ──────────────────────────────────────────────────────────────────
function App() {
  const [page, setPage] = useState("Dashboard");
  const [lang, setLang] = useState(() => localStorage.getItem("lm_lang") || "en");
  const [toast, setToast] = useState(null);
  const [diagHistory, setDiagHistory] = useState(() => {
    try { return JSON.parse(localStorage.getItem("lm_history") || "[]"); } catch { return []; }
  });
  const [chatHistory, setChatHistory] = useState([]);
  const [diagResult, setDiagResult] = useState(null);

  const showToast = (msg) => setToast(msg);

  const changeLang = (l) => { setLang(l); localStorage.setItem("lm_lang", l); };

  const addDiagHistory = (entry) => {
    const next = [entry, ...diagHistory].slice(0, 50);
    setDiagHistory(next);
    localStorage.setItem("lm_history", JSON.stringify(next));
  };

  const removeDiagHistory = (id) => {
    const next = diagHistory.filter(d => d.id !== id);
    setDiagHistory(next);
    localStorage.setItem("lm_history", JSON.stringify(next));
    showToast("Removed from history");
  };

  const PAGES = ["Dashboard", "Diagnose", "AgroBot", "History"];

  return (
    <div className="app">
      <style>{css}</style>
      {toast && <Toast msg={toast} onClose={() => setToast(null)} />}
      <header className="header">
        <div className="header-inner">
          <div className="logo">
            <div className="logo-icon">🌿</div>
            <span className="logo-text">LeafMind</span>
          </div>
          <nav className="nav">
            {PAGES.map(p => (
              <button key={p} className={`nav-btn${page===p?" active":""}`} onClick={() => setPage(p)}>{p}</button>
            ))}
          </nav>
          <div className="header-right">
            <select className="lang-select" value={lang} onChange={e => changeLang(e.target.value)}>
              {LANGUAGES.map(l => <option key={l.code} value={l.code}>{l.label}</option>)}
            </select>
            <button className="btn btn-ghost" style={{fontSize:".8rem",padding:".35rem .75rem"}} onClick={() => {
              localStorage.removeItem("lm_auth");
              localStorage.removeItem("lm_username");
              window.location.reload();
            }}>Sign Out</button>
          </div>
        </div>
        <div style={{display:"flex",gap:".5rem",overflowX:"auto",padding:".4rem 1.5rem .6rem",maxWidth:"1100px",margin:"0 auto"}} className="mobile-nav">
          {PAGES.map(p => (
            <button key={p} className={`nav-btn${page===p?" active":""}`} onClick={() => setPage(p)} style={{whiteSpace:"nowrap"}}>{p}</button>
          ))}
        </div>
      </header>
      <main className="main">
        {page === "Dashboard" && <Dashboard diagHistory={diagHistory} setPage={setPage} lang={lang} />}
        {page === "Diagnose" && <DiagnosePage lang={lang} onResult={(r) => { setDiagResult(r); addDiagHistory(r); showToast("Diagnosis complete!"); }} diagResult={diagResult} setDiagResult={setDiagResult} />}
        {page === "AgroBot" && <AgrobotPage lang={lang} chatHistory={chatHistory} setChatHistory={setChatHistory} showToast={showToast} />}
        {page === "History" && <HistoryPage diagHistory={diagHistory} onRemove={removeDiagHistory} />}
      </main>
    </div>
  );
}

// ── Dashboard ────────────────────────────────────────────────────────────────
function Dashboard({ diagHistory, setPage, lang }) {
  const severe = diagHistory.filter(d => d.severity === "severe").length;
  const healthy = diagHistory.filter(d => (d.disease_name||"").toLowerCase() === "healthy").length;
  return (
    <div>
      <div className="hero">
        <h1>🌿 LeafMind</h1>
        <p>AI plant disease diagnosis for every farmer · 9 Indian languages</p>
      </div>
      <div className="stats-grid">
        <div className="stat-card"><div className="stat-label">🌱 Total Scans</div><div className="stat-value">{diagHistory.length}</div></div>
        <div className="stat-card"><div className="stat-label">⚠️ Severe Cases</div><div className="stat-value">{severe}</div></div>
        <div className="stat-card"><div className="stat-label">✨ Healthy</div><div className="stat-value">{healthy}</div></div>
      </div>
      <div style={{display:"flex",gap:"1rem",marginBottom:"2rem",flexWrap:"wrap"}}>
        <button className="btn btn-primary" onClick={() => setPage("Diagnose")}>🔬 New Diagnosis</button>
        <button className="btn btn-outline" onClick={() => setPage("AgroBot")}>💬 Ask AgroBot</button>
      </div>
      {diagHistory.length > 0 && (
        <div>
          <h2 style={{marginBottom:"1rem",fontSize:"1.4rem"}}>Recent diagnoses</h2>
          <div className="history-grid">
            {diagHistory.slice(0,6).map(d => <MiniCard key={d.id} d={d} />)}
          </div>
        </div>
      )}
      <div style={{marginTop:"2rem",padding:"1.5rem",background:"var(--secondary)",borderRadius:"var(--radius)",border:"1px solid var(--border)"}}>
        <h3 style={{marginBottom:".75rem",fontSize:"1.2rem"}}>🌍 AgroBot speaks your language</h3>
        <p style={{color:"var(--muted)",fontSize:".875rem",marginBottom:"1rem"}}>Ask farming questions in any of 9 languages — get expert answers about diseases, pests, fertilization and more.</p>
        <div style={{display:"flex",flexWrap:"wrap",gap:".4rem"}}>
          {LANGUAGES.map(l => <span key={l.code} style={{background:"var(--card)",border:"1px solid var(--border)",borderRadius:"9999px",padding:".2rem .75rem",fontSize:".8rem"}}>{l.label}</span>)}
        </div>
      </div>
    </div>
  );
}

function MiniCard({ d }) {
  return (
    <div className="history-card" style={{cursor:"default"}}>
      <div className="history-img">
        {d.image_url ? <img src={d.image_url} alt="" /> : <span style={{fontSize:"2rem"}}>🌿</span>}
      </div>
      <div className="history-body">
        <div className="history-crop">{d.crop}</div>
        <div className="history-name">{d.disease_name || "Unknown"}</div>
        <div className="history-date">{d.created_at}</div>
        <SeverityBadge severity={d.severity} />
      </div>
    </div>
  );
}

// ── Diagnose ──────────────────────────────────────────────────────────────────
function DiagnosePage({ lang, onResult, diagResult, setDiagResult }) {
  const [imagePreview, setImagePreview] = useState("");
  const [imageData, setImageData] = useState("");
  const [crop, setCrop] = useState("rice");
  const [temp, setTemp] = useState("28");
  const [hum, setHum] = useState("70");
  const [rain, setRain] = useState("0");
  const [busy, setBusy] = useState(false);
  const [diagLang, setDiagLang] = useState(lang);
  const [wxStatus, setWxStatus] = useState("");
  const fileRef = useRef();

  useEffect(() => { setDiagLang(lang); }, [lang]);

  const autoWeather = useCallback(async () => {
    if (!navigator.geolocation) { setWxStatus("Geolocation not supported by this browser."); return; }
    setWxStatus("📍 Detecting location…");
    navigator.geolocation.getCurrentPosition(async (pos) => {
      try {
        setWxStatus("🌤 Fetching weather…");
        const { latitude: lat, longitude: lon } = pos.coords;
        const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m&daily=precipitation_sum&forecast_days=1&timezone=auto`;
        const r = await fetch(url);
        const d = await r.json();
        setTemp(String(Math.round(d.current.temperature_2m)));
        setHum(String(Math.round(d.current.relative_humidity_2m)));
        setRain(String(Math.round(d.daily?.precipitation_sum?.[0] || 0)));
        setWxStatus("✅ Weather auto-filled from your location!");
        setTimeout(() => setWxStatus(""), 3000);
      } catch(e) {
        setWxStatus("Could not fetch weather. Please enter manually.");
      }
    }, () => setWxStatus("Location access denied. Please enter weather manually."));
  }, []);

  useEffect(() => { autoWeather(); }, []);

  const onFile = (file) => {
    if (!file) return;
    if (file.size > 8 * 1024 * 1024) { alert("Image must be under 8MB"); return; }
    const reader = new FileReader();
    reader.onload = () => { setImageData(reader.result); setImagePreview(reader.result); };
    reader.readAsDataURL(file);
  };

  const run = async () => {
    if (!imageData) return;
    setBusy(true);
    try {
      const res = await fetch("/api/diagnose", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ image: imageData, crop, temperature: +temp||null, humidity: +hum||null, rainfall: +rain||null, language: diagLang }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const r = await res.json();
      if (r.error) throw new Error(r.error);
      r.id = crypto.randomUUID();
      r.crop = crop;
      r.created_at = new Date().toLocaleString();
      r.image_url = imagePreview.length < 200000 ? imagePreview : null;
      onResult(r);
    } catch(e) {
      alert("Diagnosis failed: " + e.message);
    } finally { setBusy(false); }
  };

  return (
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"1.5rem",alignItems:"start"}}>
      <style>{`@media(max-width:700px){.diag-grid{grid-template-columns:1fr!important}}`}</style>
      <div className="diag-grid" style={{gridColumn:"1/-1",display:"grid",gridTemplateColumns:"1fr 1fr",gap:"1.5rem",alignItems:"start"}}>
        <div className="card">
          <h2 style={{marginBottom:"1rem",fontSize:"1.4rem"}}>🔬 New Scan</h2>
          <div className="upload-zone" onClick={() => fileRef.current?.click()}>
            {imagePreview ? <img src={imagePreview} alt="leaf" /> :
              <div className="upload-text">
                <div style={{fontSize:"2.5rem",marginBottom:".5rem"}}>📷</div>
                <div style={{fontWeight:600}}>Tap to upload leaf photo</div>
                <div style={{fontSize:".8rem",color:"var(--muted)",marginTop:".25rem"}}>JPG or PNG, up to 8MB</div>
              </div>
            }
          </div>
          <input ref={fileRef} type="file" accept="image/*" capture="environment" style={{display:"none"}} onChange={e => onFile(e.target.files[0])} />
          {imagePreview && <button className="btn btn-ghost" style={{marginTop:".5rem",fontSize:".8rem"}} onClick={() => {setImagePreview("");setImageData("");}}>✕ Remove photo</button>}

          <div className="form-group" style={{marginTop:"1rem"}}>
            <label className="form-label">🌾 Crop Type</label>
            <select className="form-select" value={crop} onChange={e => setCrop(e.target.value)}>
              {CROPS.map(c => <option key={c} value={c}>{c.charAt(0).toUpperCase()+c.slice(1)}</option>)}
            </select>
          </div>
          <details style={{marginBottom:"1rem"}}>
            <summary style={{cursor:"pointer",fontSize:".85rem",fontWeight:600,color:"var(--primary)",padding:".5rem 0"}}>🌤 Weather context (improves accuracy)</summary>
            <div style={{paddingTop:".75rem",display:"grid",gridTemplateColumns:"1fr 1fr",gap:".75rem"}}>
              <div className="form-group" style={{marginBottom:0}}><label className="form-label">Temp (°C)</label><input className="form-input" type="number" value={temp} onChange={e=>setTemp(e.target.value)} placeholder="28" /></div>
              <div className="form-group" style={{marginBottom:0}}><label className="form-label">Humidity (%)</label><input className="form-input" type="number" value={hum} onChange={e=>setHum(e.target.value)} placeholder="70" /></div>
              <div className="form-group" style={{marginBottom:0,gridColumn:"1/-1"}}><label className="form-label">Rainfall last 7d (mm)</label><input className="form-input" type="number" value={rain} onChange={e=>setRain(e.target.value)} placeholder="0" /></div>
            </div>
          </details>
          <div className="form-group">
            <label className="form-label">📢 Result Language</label>
            <select className="form-select" value={diagLang} onChange={e => setDiagLang(e.target.value)}>
              {LANGUAGES.map(l => <option key={l.code} value={l.code}>{l.label}</option>)}
            </select>
          </div>
          <button className="btn btn-primary" style={{width:"100%",justifyContent:"center"}} onClick={run} disabled={!imageData||busy}>
            {busy ? "Analyzing…" : "✨ Run Diagnosis"}
          </button>
        </div>

        <div>
          {!diagResult && !busy && (
            <div className="card" style={{textAlign:"center",padding:"3rem 2rem"}}>
              <div style={{fontSize:"3rem",marginBottom:"1rem"}}>🌿</div>
              <h3 style={{marginBottom:".5rem"}}>Your diagnosis appears here</h3>
              <p style={{color:"var(--muted)",fontSize:".875rem"}}>Upload a leaf photo and click Run Diagnosis.</p>
            </div>
          )}
          {busy && (
            <div className="card" style={{textAlign:"center",padding:"3rem 2rem"}}>
              <div style={{width:"3rem",height:"3rem",borderRadius:"50%",border:"3px solid var(--border)",borderTopColor:"var(--primary)",animation:"spin .7s linear infinite",margin:"0 auto 1rem"}} />
              <h3>Analyzing leaf…</h3>
              <p style={{color:"var(--muted)",fontSize:".875rem",marginTop:".5rem"}}>This usually takes a few seconds.</p>
            </div>
          )}
          {diagResult && <DiagResult r={diagResult} onClear={() => setDiagResult(null)} />}
        </div>
      </div>
    </div>
  );
}

function DiagResult({ r, onClear }) {
  return (
    <div>
      <div className="result-header">
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
          <span style={{fontSize:".7rem",textTransform:"uppercase",letterSpacing:".1em",opacity:.7}}>Diagnosis</span>
          <SeverityBadge severity={r.severity} />
        </div>
        <h2>{r.disease_name}</h2>
        <div style={{fontSize:".85rem",opacity:.8}}>Confidence: {Math.round((r.confidence||0)*100)}%</div>
      </div>
      <div className="result-body">
        {r.description && <><div className="section-title">Description</div><p className="section-body" style={{marginBottom:"1rem"}}>{r.description}</p></>}
        <div className="info-panels">
          {r.treatment && <div className="card" style={{padding:"1rem"}}><div className="section-title">💊 Treatment</div><p className="section-body" style={{fontSize:".85rem"}}>{r.treatment}</p></div>}
          {r.prevention && <div className="card" style={{padding:"1rem"}}><div className="section-title">🛡 Prevention</div><p className="section-body" style={{fontSize:".85rem"}}>{r.prevention}</p></div>}
        </div>
        {r.severity === "severe" && <div style={{marginTop:"1rem",padding:"1rem",background:"#fee2e2",borderRadius:".75rem",fontSize:".875rem",color:"#991b1b",border:"1px solid #fca5a5"}}>⚠️ High severity — consider consulting a local agricultural extension officer.</div>}
        <button className="btn btn-ghost" style={{marginTop:"1rem",fontSize:".8rem"}} onClick={onClear}>✕ Clear result</button>
      </div>
    </div>
  );
}

// ── AgroBot ───────────────────────────────────────────────────────────────────
function AgrobotPage({ lang, chatHistory, setChatHistory, showToast }) {
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const bottomRef = useRef();
  const textareaRef = useRef();

  const onVoiceResult = useCallback((transcript) => {
    setInput(transcript);
    showToast("🎤 Transcribed: " + transcript.substring(0, 40) + (transcript.length > 40 ? "…" : ""));
  }, [showToast]);

  const { recording, supported, start, stop } = useVoiceInput(onVoiceResult);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [chatHistory, busy]);

  const send = async (content) => {
    if (!content.trim() || busy) return;
    const msgs = [...chatHistory, { role: "user", content: content.trim() }];
    setChatHistory(msgs);
    setInput("");
    setBusy(true);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: msgs.map(m => ({role:m.role,content:m.content})), language: lang }),
      });
      if (!res.ok) {
        let errMsg;
        if (res.status === 429) errMsg = "⏳ Rate limit reached — your OpenAI key has too many requests. Please wait 1 minute then try again. If this keeps happening, add billing at platform.openai.com/billing";
        else if (res.status === 401) errMsg = "🔑 Invalid API key — check OPENAI_API_KEY in backend/.env";
        else if (res.status === 503) { try { const d = await res.json(); errMsg = "⚙️ " + (d.error || "Server not configured"); } catch(_) { errMsg = "Server unavailable"; } }
        else errMsg = "Server error (HTTP " + res.status + ")";
        throw new Error(errMsg);
      }
      const data = await res.json();
      const reply = data.reply || data.error || "No response.";
      setChatHistory(prev => [...prev, { role: "assistant", content: reply, ts: new Date() }]);
    } catch(e) {
      setChatHistory(prev => [...prev, { role: "assistant", content: "⚠️ Error: " + e.message }]);
    } finally { setBusy(false); }
  };

  const onKey = (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(input); } };

  const suggestions = SUGGESTED[lang] || SUGGESTED.en;
  const langLabel = LANGUAGES.find(l => l.code === lang)?.label || "English";

  return (
    <div>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:"1rem",flexWrap:"wrap",gap:".75rem"}}>
        <div style={{display:"flex",alignItems:"center",gap:".75rem"}}>
          <div style={{width:"2.75rem",height:"2.75rem",background:"linear-gradient(135deg,#1a4731,#2d6a4f)",borderRadius:".75rem",display:"grid",placeItems:"center",fontSize:"1.3rem"}}>🤖</div>
          <div>
            <h1 style={{fontSize:"1.5rem",margin:0}}>AgroBot</h1>
            <p style={{color:"var(--muted)",fontSize:".8rem",margin:0}}>AI farming assistant · replying in <strong>{langLabel}</strong></p>
          </div>
        </div>
        {chatHistory.length > 0 && <button className="btn btn-outline" style={{fontSize:".8rem"}} onClick={() => setChatHistory([])}>🗑 Clear</button>}
      </div>

      <div className="chat-wrap">
        <div className="chat-messages">
          {chatHistory.length === 0 && (
            <div style={{margin:"auto",textAlign:"center",padding:"2rem 1rem"}}>
              <div style={{fontSize:"3rem",marginBottom:"1rem"}}>🌾</div>
              <h3 style={{marginBottom:".5rem"}}>Ask me anything about farming</h3>
              <p style={{color:"var(--muted)",fontSize:".875rem",marginBottom:"1.5rem"}}>I answer in <strong>{langLabel}</strong> — diseases, pests, fertilizers, irrigation and more.</p>
              {supported && <div style={{background:"#f0f5ec",border:"1px solid var(--border)",borderRadius:".75rem",padding:".75rem 1rem",fontSize:".8rem",color:"var(--primary)",marginBottom:"1.5rem"}}>🎤 Voice input supported — tap the mic button to speak!</div>}
              <div className="suggestions">
                {suggestions.map((q, i) => (
                  <button key={i} className="suggestion-btn" onClick={() => send(q)} disabled={busy}>{q}</button>
                ))}
              </div>
            </div>
          )}

          {chatHistory.map((msg, i) => (
            <div key={i} className={`chat-msg ${msg.role}`}>
              <div className={`chat-avatar ${msg.role}`}>{msg.role === "user" ? "👤" : "🤖"}</div>
              <div>
                <div className={`chat-bubble ${msg.role}`}>{msg.content}</div>
                {msg.ts && <div className={`chat-time`} style={{textAlign: msg.role==="user"?"right":"left"}}>{new Date(msg.ts).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}</div>}
              </div>
            </div>
          ))}

          {busy && (
            <div className="chat-msg">
              <div className="chat-avatar bot">🤖</div>
              <div className="chat-bubble bot">
                <div className="typing"><span /><span /><span /></div>
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {recording && (
          <div className="voice-bar">
            <span style={{width:".6rem",height:".6rem",background:"var(--destructive)",borderRadius:"50%",animation:"pulse 1s infinite",display:"inline-block"}} />
            🎤 Listening… speak now. Tap mic to stop.
          </div>
        )}

        <div className="chat-input-bar">
          {supported && (
            <button
              className={`btn-voice${recording ? " recording" : ""}`}
              onClick={() => recording ? stop() : start(lang)}
              title={recording ? "Stop recording" : "Start voice input"}
            >
              🎤
            </button>
          )}
          <textarea
            ref={textareaRef}
            className="chat-textarea"
            rows={2}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={onKey}
            placeholder={`Ask in ${langLabel}… (Enter to send, Shift+Enter for new line)`}
            disabled={busy}
          />
          <button className="btn btn-primary" onClick={() => send(input)} disabled={!input.trim() || busy} style={{flexShrink:0,alignSelf:"flex-end"}}>
            📤
          </button>
        </div>
        <div className="chat-hint">Enter to send · Shift+Enter for new line · Always verify critical decisions with an agronomist</div>
      </div>
    </div>
  );
}

// ── History ────────────────────────────────────────────────────────────────────
function HistoryPage({ diagHistory, onRemove }) {
  const [selected, setSelected] = useState(null);

  return (
    <div>
      <h1 style={{marginBottom:".5rem",fontSize:"1.75rem"}}>📋 Diagnosis History</h1>
      <p style={{color:"var(--muted)",marginBottom:"1.5rem"}}>Every scan you've run, ready to revisit.</p>

      {diagHistory.length === 0 ? (
        <div className="card" style={{textAlign:"center",padding:"3rem"}}>
          <div style={{fontSize:"2.5rem",marginBottom:"1rem"}}>🌿</div>
          <p style={{color:"var(--muted)"}}>No history yet. Run your first diagnosis.</p>
        </div>
      ) : (
        <div className="history-grid">
          {diagHistory.map(d => (
            <div key={d.id} className="history-card" onClick={() => setSelected(d)}>
              <div className="history-img">
                {d.image_url ? <img src={d.image_url} alt="" /> : <span style={{fontSize:"2.5rem"}}>🌿</span>}
              </div>
              <div className="history-body">
                <div className="history-crop">{d.crop}</div>
                <div className="history-name">{d.disease_name || "Unknown"}</div>
                <div className="history-date">{d.created_at}</div>
                <SeverityBadge severity={d.severity} />
              </div>
            </div>
          ))}
        </div>
      )}

      {selected && (
        <div className="modal-overlay" onClick={() => setSelected(null)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            {selected.image_url && <img src={selected.image_url} alt="" style={{width:"100%",height:"220px",objectFit:"cover",borderRadius:"1.25rem 1.25rem 0 0"}} />}
            <div className="modal-header" style={{borderRadius: selected.image_url ? "0" : "1.25rem 1.25rem 0 0"}}>
              <div style={{fontSize:".7rem",opacity:.7,textTransform:"uppercase",letterSpacing:".1em"}}>{selected.crop} · {selected.created_at}</div>
              <h2 style={{color:"white",margin:".3rem 0",fontSize:"1.5rem"}}>{selected.disease_name}</h2>
              <div style={{display:"flex",alignItems:"center",gap:".75rem",flexWrap:"wrap"}}>
                <SeverityBadge severity={selected.severity} />
                {selected.confidence != null && <span style={{fontSize:".75rem",opacity:.8}}>Confidence: {Math.round((selected.confidence||0)*100)}%</span>}
              </div>
            </div>
            <div className="modal-body">
              {selected.description && <><div className="section-title">Description</div><p className="section-body" style={{marginBottom:"1rem"}}>{selected.description}</p></>}
              {selected.treatment && <><div className="section-title">💊 Treatment</div><p className="section-body" style={{marginBottom:"1rem"}}>{selected.treatment}</p></>}
              {selected.prevention && <><div className="section-title">🛡 Prevention</div><p className="section-body" style={{marginBottom:"1rem"}}>{selected.prevention}</p></>}
              <div style={{display:"flex",gap:".75rem",marginTop:"1rem"}}>
                <button className="btn btn-outline" onClick={() => setSelected(null)}>Close</button>
                <button className="btn btn-danger" onClick={() => { onRemove(selected.id); setSelected(null); }}>🗑 Delete</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Mount ─────────────────────────────────────────────────────────────────────
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
