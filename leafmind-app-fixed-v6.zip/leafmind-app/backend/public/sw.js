
// LeafMind SW — cache buster. Clears everything so updates always show.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(keys.map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});
// No caching — always go to network
self.addEventListener('fetch', event => {
  event.respondWith(fetch(event.request).catch(() => new Response('Offline', { status: 503 })));
});
