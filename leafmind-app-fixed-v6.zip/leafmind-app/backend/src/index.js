import express from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";
import "dotenv/config";
import chatRouter from "./routes/chat.js";
import diagnoseRouter from "./routes/diagnose.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json({ limit: "25mb" }));

if (!process.env.OPENAI_API_KEY) {
  console.warn("\n⚠  OPENAI_API_KEY not set — AI features will not work.");
  console.warn("   Copy backend/.env.example to backend/.env and add your key.\n");
}

app.get("/api/healthz", (_req, res) => res.json({ ok: true }));
app.use("/api/chat", chatRouter);
app.use("/api/diagnose", diagnoseRouter);

const staticDir = path.join(__dirname, "..", "public");
app.use(express.static(staticDir));
app.get("*", (_req, res) => res.sendFile(path.join(staticDir, "index.html")));

app.listen(PORT, () => {
  console.log(`\nLeafMind running at http://localhost:${PORT}`);
  console.log(`Login: admin / leafmind123  (or create a new account)\n`);
});
