import { Router } from "express";
import "dotenv/config";

const router = Router();

const LANG_NAMES = {
  en: "English", hi: "Hindi", kn: "Kannada", te: "Telugu",
  ta: "Tamil",   mr: "Marathi", bn: "Bengali", gu: "Gujarati", pa: "Punjabi"
};
const LANG_CODES = {
  en: "en", hi: "hi", kn: "kn", te: "te",
  ta: "ta", mr: "mr", bn: "bn", gu: "gu", pa: "pa"
};

// ─── Google Translate (completely free, no API key) ───────────────────────────
async function gtranslate(text, sourceLang, targetLang) {
  if (!text || !text.trim()) return text;
  if (sourceLang === targetLang) return text;
  try {
    const sl  = LANG_CODES[sourceLang] || "auto";
    const tl  = LANG_CODES[targetLang] || "en";
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${sl}&tl=${tl}&dt=t&q=${encodeURIComponent(text)}`;
    const res = await fetch(url, {
      headers: { "User-Agent": "Mozilla/5.0" },
      signal:  AbortSignal.timeout(12000),
    });
    if (!res.ok) return text;
    const data = await res.json();
    if (!Array.isArray(data?.[0])) return text;
    return data[0].map(s => (Array.isArray(s) ? s[0] : "")).join("") || text;
  } catch (_) { return text; }
}

async function translateLong(text, targetLang) {
  if (!text || targetLang === "en") return text;
  const MAX = 4500;
  if (text.length <= MAX) return gtranslate(text, "en", targetLang);
  const paras = text.split(/\n\n+/);
  const chunks = []; let cur = "";
  for (const p of paras) {
    if (cur.length + p.length + 2 > MAX && cur) { chunks.push(cur); cur = p; }
    else { cur = cur ? cur + "\n\n" + p : p; }
  }
  if (cur) chunks.push(cur);
  const parts = [];
  for (const c of chunks) parts.push(await gtranslate(c, "en", targetLang));
  return parts.join("\n\n");
}

// ════════════════════════════════════════════════════════════════════════════
//  KNOWLEDGE BASE
//  tags: array of exact keywords/phrases. Search uses WHOLE-WORD matching.
// ════════════════════════════════════════════════════════════════════════════
const KB = [

  // ─── WEATHER ──────────────────────────────────────────────────────────────
  { tags: ["weather", "rain", "monsoon", "rainfall", "climate", "forecast", "mausam", "barish", "meghdoot"],
    answer: `Weather Guide for Farmers

Best Free Apps:
- Meghdoot App (IMD): 5-day agro-weather advisory, block-level, crop-specific. Best for farmers.
- Damini App: Real-time lightning alerts. Critical for field safety.
- Kisan Suvidha App: Weather + market prices + expert advice in one place.
- mausam.imd.gov.in: District-level forecasts.

How Weather Affects Crops:
- Temperature above 35°C: Heat stress, flower drop, poor pollination.
- Humidity above 80% + warm nights: Fungal diseases (blast, rust, blight). Spray preventive fungicide.
- Heavy rain after dry spell: Fruit cracking in tomato/mango. Keep irrigation consistent.
- Cold below 10°C: Damages banana, papaya. Cover seedlings at night.
- Hot dry winds (Loo): Mulch soil, irrigate in evening, spray antitranspirant.

Seasonal Crop Calendar:
- Kharif (June-Oct): Rice, Maize, Cotton, Soybean, Groundnut, Tomato
- Rabi (Nov-Mar): Wheat, Mustard, Chickpea, Potato, Onion
- Zaid (Mar-Jun): Watermelon, Cucumber, Moong

Kisan Helpline: 1800-180-1551 (Free, all days)` },

  // ─── TEMPERATURE ──────────────────────────────────────────────────────────
  { tags: ["temperature", "heat", "frost", "cold wave", "heat wave", "heat stress", "cold stress"],
    answer: `Temperature Effects on Crops

Optimal Ranges:
- Rice: 22-28°C at flowering. Above 35°C causes empty grains.
- Wheat: 12-18°C for grain filling. Above 30°C reduces grain weight.
- Maize: 20-28°C at pollination. Above 38°C kills pollen.
- Tomato: 20-27°C for fruit set. Below 10 or above 32°C causes flower drop.
- Cotton: 27-37°C. Above 40°C causes boll shedding.
- Potato: 15-20°C for tuber formation. Above 29°C stops tuber growth.

Heat Stress Management:
- Irrigate only at 6-9 AM or 4-6 PM. Never in afternoon.
- Potassium Nitrate 1% foliar spray improves heat tolerance.
- 5-7 cm straw mulch reduces soil temperature by 5-8°C.
- Choose heat-tolerant varieties for your zone.

Frost and Cold Protection:
- Irrigate before expected frost night (freezing water releases heat).
- Burn crop residue upwind at night to raise field temperature.
- Cover seedlings with plastic or cloth before sunset.
- Potassium fertilizer strengthens cell walls against cold damage.` },

  // ─── SOIL ─────────────────────────────────────────────────────────────────
  { tags: ["soil", "land", "black soil", "red soil", "sandy", "clay", "loam", "soil type", "soil structure", "soil preparation"],
    answer: `Soil Types and Preparation Guide

Major Soil Types in India:
1. Black Cotton Soil: High clay, holds moisture. Maharashtra, MP, Gujarat, Telangana. Best for cotton, sorghum, wheat. Needs deep plowing 30-35 cm.
2. Red and Yellow Soil: Low fertility, drains well. AP, Karnataka, Tamil Nadu. Add lots of organic matter. Good for groundnut, pulses, millets.
3. Alluvial Soil: Most fertile. Indo-Gangetic plains. Excellent for rice, wheat, sugarcane, vegetables.
4. Laterite Soil: Acidic, poor nutrients. Kerala, Odisha, West Bengal hills. Apply lime. Good for cashew, rubber, tea.
5. Sandy Loam: Easy to work, well-drained. Good for vegetables, potato. Needs more frequent irrigation.

Soil Preparation Steps:
1. Deep plow 30-35 cm after previous crop harvest.
2. Cross-harrowing to break clods and level field.
3. Apply 10-15 tonnes FYM or compost per hectare, incorporate 3-4 weeks before sowing.
4. Sub-soil every 3-4 years to break hardpan.
5. Laser leveling saves 20-25% irrigation water.

Healthy Soil Signs:
- Dark color = high organic matter
- Earthworms present = active soil biology
- Water soaks in within 1-2 hours = good structure` },

  // ─── SOIL TEST ────────────────────────────────────────────────────────────
  { tags: ["soil test", "soil testing", "ph", "acidic", "alkaline", "soil health card", "soil fertility", "soil nutrients"],
    answer: `Soil Testing - Complete Guide

Why Test Soil?
- Prevents wasting money on fertilizers you don't need.
- Finds hidden deficiencies before crop failure.
- Gives exact NPK and micronutrient recommendations.

How to Collect a Soil Sample:
1. Walk in zigzag pattern, collect from 10-15 spots.
2. Depth: 0-15 cm for annual crops, 0-30 cm for sugarcane and fruit trees.
3. Mix all sub-samples in a clean bucket. Take 500g final sample.
4. Label with field name and date. Dry in shade.

Where to Test:
- Krishi Vigyan Kendra (KVK): Usually free.
- State Agriculture Department Lab: Rs 20-50 per sample.
- Soil Health Card Scheme: Free test + printed recommendations at soilhealth.dac.gov.in.

Reading Results:
- pH 6.5-7.5: Ideal for most crops.
- pH below 6 (acidic): Apply agricultural lime 1-2 tonnes per hectare.
- pH above 8 (alkaline): Apply gypsum 2-3 tonnes per hectare.
- EC above 4 mS/cm: Salt problem. Leach field with water, grow tolerant crops.
- Organic Carbon below 0.5%: URGENT. Add 10+ tonnes FYM per hectare.` },

  // ─── IRRIGATION ───────────────────────────────────────────────────────────
  { tags: ["irrigation", "drip", "sprinkler", "irrigate", "watering", "water management", "flood irrigation"],
    answer: `Irrigation Methods and Schedule

Method Comparison:
1. Drip Irrigation (90% efficient): Vegetables, fruits, cotton, banana. Saves 40-60% water. PMKSY subsidy: 55-90%.
2. Sprinkler (75-85%): Wheat, vegetables, uneven land.
3. Flood (40-60%): Only justified for rice and sugarcane.

When to Irrigate Each Crop:
- Rice: Maintain 2-5 cm standing water. AWD (dry-then-refill) saves 30% water with no yield loss.
- Wheat: At 21, 45, 65, 85, and 105 days after sowing. These 5 irrigations are critical.
- Maize: Never miss at tasseling and silking. Yield loss is permanent.
- Tomato: Consistent moisture. Irregular watering causes blossom end rot and fruit cracking.
- Cotton: Critical at square formation, flowering, and boll development. Never waterlog.
- Potato: Keep consistent moisture. Drought causes small and cracked tubers.

Field Moisture Check (No Instruments):
- Sandy soil: If squeezed soil crumbles immediately on opening hand - irrigate now.
- Loam: If soil holds shape but crumbles when dropped - moisture adequate.
- Clay: If it forms a ribbon and does not crack - too wet, do not irrigate.

Water Saving Tips:
- Irrigate at 6-9 AM or 5-7 PM. Midday loses 30% to evaporation.
- 5-7 cm mulch reduces irrigation need by 30-40%.
- Fix a 1mm pipe leak immediately - it wastes 5,000 litres per day.` },

  // ─── MARKET PRICES ────────────────────────────────────────────────────────
  { tags: ["market", "price", "mandi", "selling", "msp", "minimum support price", "enam", "agmarknet", "market rate", "crop price", "selling price"],
    answer: `Getting the Best Price for Your Crops

Check Today's Mandi Prices:
1. eNAM App (enam.gov.in): Live prices from 1,200+ mandis. Online bidding gets more buyers.
2. Agmarknet (agmarknet.gov.in): Historical trends. Check before deciding when to sell.
3. Kisan Suvidha App: Daily mandi prices with trend charts.
4. SMS: Send "MANDI [crop] [state]" to 51969 for free price alert.

Minimum Support Price (MSP) 2024-25:
- Paddy (Common): Rs 2,300 per quintal
- Wheat: Rs 2,275 per quintal
- Maize: Rs 2,090 per quintal
- Soybean: Rs 4,892 per quintal
- Groundnut: Rs 6,783 per quintal
- Cotton (medium): Rs 7,121 per quintal
- Arhar/Tur: Rs 7,550 per quintal
- Gram (Chickpea): Rs 5,440 per quintal
- Sunflower: Rs 7,280 per quintal

Strategies to Get Better Price:
- Grade and sort: Uniform quality gets 15-25% premium.
- Warehouse Receipt: Store in certified warehouse, take loan, sell when prices rise.
- FPO collective selling: Group bargaining gets better price.
- Direct marketing: Farmers markets, WhatsApp buyer groups, eNAM online.

Price Seasons:
- Tomato: Peak prices March-June. Glut: October-December.
- Onion: Best January-March. Worst September-October (harvest glut).
- Paddy: Best February-May. Worst October-November (everyone selling at once).` },

  // ─── CROP SELECTION ───────────────────────────────────────────────────────
  { tags: ["crop selection", "which crop", "profitable crop", "best crop", "crop planning", "what to grow", "kharif", "rabi", "zaid"],
    answer: `Crop Selection Guide

Kharif Season (Sow June-July, Harvest October-November):
- Cereals: Rice, Maize, Sorghum, Pearl Millet
- Oilseeds: Soybean, Groundnut, Sunflower, Sesame
- Pulses: Pigeonpea (Tur), Moong, Urad, Cowpea
- Cash crops: Cotton, Sugarcane, Turmeric, Ginger
- Vegetables: Tomato, Brinjal, Lady's Finger, Cucumber

Rabi Season (Sow November-December, Harvest March-April):
- Cereals: Wheat, Barley
- Oilseeds: Mustard, Rapeseed
- Pulses: Chickpea, Lentil, Fieldpea
- Vegetables: Potato, Onion, Cabbage, Cauliflower, Carrot, Pea

High Value Profitable Options:
- Dragon fruit: Very low water, Rs 100-200/kg, 7-8 year productive life.
- Strawberry: 4-month crop, Rs 80-150/kg.
- Baby corn: 65-day crop, 3 crops/year, Rs 20-30/kg fresh.
- Turmeric: Rs 8,000-12,000/quintal, very stable demand.
- Mushroom: Indoor, no land needed, Rs 80-200/kg, 10-15 cycles/year.

Choosing the Right Crop:
1. Water availability through entire season.
2. Distance to nearest market.
3. Climate and agro-zone suitability.
4. Input availability locally.
5. Labour during sowing and harvest.` },

  // ─── FERTILIZERS GENERAL ──────────────────────────────────────────────────
  { tags: ["fertilizer", "fertiliser", "npk", "urea", "dap", "potash", "manure", "nitrogen", "phosphorus", "potassium", "khad", "gobbara", "enuvulu"],
    answer: `Complete Fertilizer Guide

The Three Main Nutrients (NPK):

NITROGEN (N) - Makes plants green and leafy:
- Source: Urea (46% N, cheapest), Ammonium Sulphate (21% N), CAN (26% N)
- Deficiency: Yellowing from lower/older leaves upward.
- Excess: Excessive leafy growth, lodging, delayed maturity, more disease.
- Always split into 3-4 doses. Never apply all at once.

PHOSPHORUS (P) - Builds roots, flowers, seeds:
- Source: DAP (18% N + 46% P), SSP (16% P, cheapest), TSP
- Deficiency: Purple-red leaf color, stunted roots, delayed maturity.
- Apply full dose as basal before sowing. Phosphorus does not move in soil.

POTASSIUM (K) - Fights disease, improves quality:
- Source: MOP (60% K), SOP (50% K, better quality, less chloride)
- Deficiency: Leaf tip and margin burning on older leaves.
- Apply half as basal, half at flowering.

NPK Doses by Crop (kg per hectare):
- Rice: 120-60-60
- Wheat: 120-60-40
- Maize: 150-75-60
- Tomato: 150-75-75
- Cotton: 150-75-75
- Sugarcane: 250-115-115
- Groundnut: 25-50-75 (low N, fixes own nitrogen)
- Onion: 100-50-50
- Potato: 200-150-150
- Soybean: 20-80-40

Key Rules:
- Get soil tested before deciding doses.
- Over-fertilizing wastes money and pollutes groundwater.
- Always apply biofertilizer LAST after chemicals.` },

  // ─── TOMATO ───────────────────────────────────────────────────────────────
  { tags: ["tomato", "tomato fertilizer", "tomato cultivation", "tomato farming", "tomato disease", "tomato growing", "tomato nutrients"],
    answer: `Tomato Cultivation and Fertilizer Guide

Variety Selection:
- Hybrid varieties: Arka Rakshak (virus resistant), Arka Samrat, PKM-1.
- Avoid sowing during heavy monsoon (disease-prone). Best seasons: October-January and June-August.

Nursery and Transplanting:
- Seed rate: 250-400g per hectare.
- Raise seedlings for 25-30 days in nursery.
- Transplant at 45x60 cm spacing (rows x plants). Or 60x45 cm.
- Transplant in evening or on cloudy day to reduce shock.

Fertilizer (150-75-75 kg N-P-K per hectare):
Basal at transplanting:
- SSP 375 kg + MOP 125 kg + FYM 20-25 tonnes per hectare.
- ZnSO4 25 kg per hectare.

Nitrogen top-dressing (split into 4 doses):
- Day 0 (transplanting): 30% N
- 20-25 days after transplanting: 25% N
- First flowering (35-40 days): 25% N
- Fruit development (55-60 days): 20% N

Special Sprays:
- Calcium Nitrate 1% at fruiting: Prevents blossom end rot (black bottom of fruit).
- Borax 0.2% at flowering: Improves fruit set.
- MgSO4 2%: When old leaves turn yellow between veins.

Common Diseases:
- Early blight (target spots): Mancozeb 2.5g/L.
- Leaf curl virus: Control whitefly with Imidacloprid 0.25ml/L.
- Damping off (seedling collapse): Drench Carbendazim 1g/L.

Harvest:
- Ready 60-90 days after transplanting depending on variety.
- Harvest at breaker stage (first blush of red) for distant markets.
- At full red for local sale/consumption.` },

  // ─── RICE ─────────────────────────────────────────────────────────────────
  { tags: ["rice", "paddy", "rice cultivation", "paddy cultivation", "rice farming", "rice growing", "rice fertilizer", "paddy fertilizer", "rice nutrients", "dhanya"],
    answer: `Rice (Paddy) Cultivation Guide

Variety Selection:
- Short duration (110-120 days): IR-36, Pusa Basmati-1, Sahyadri
- Medium duration (130-140 days): Samba Mahsuri, MTU 1010, BPT 5204
- Long duration (150+ days): Jaya, Mahsuri
- Aromatic: Pusa Basmati-1121, Govind Bhog

Seed Rate and Nursery:
- Seed rate: 20-25 kg per hectare for transplanting, 60-80 kg for direct seeding.
- Seed treatment: Carbendazim 2g/kg before sowing.
- Nursery area: 500-750 sq m (wet bed) or 750-1000 sq m (dry bed) per hectare.
- Transplant 20-25 day old seedlings, 2-3 seedlings per hill at 20x15 cm spacing.

Fertilizer (120-60-60 kg N-P-K per hectare):
Basal at transplanting:
- 30 kg N + full 60 kg P + full 60 kg K + ZnSO4 25 kg (very important!).
Top-dressing:
- At tillering (21-25 DAT): 60 kg N (130 kg urea)
- At panicle initiation (45-50 DAT): 30 kg N (65 kg urea)

Water Management:
- Transplanting to tillering: 2-5 cm standing water.
- Maximum tillering: Drain field for 5-7 days (promotes root growth).
- Panicle initiation to grain filling: 2-5 cm water continuously.
- Grain filling to maturity: Gradually reduce and drain 15 days before harvest.
- AWD (Alternate Wetting Drying) saves 30% water with no yield loss.

Common Diseases:
- Blast: Tricyclazole 0.6g/L. Avoid excess nitrogen.
- Sheath blight: Hexaconazole 2ml/L or Propiconazole 1ml/L.
- BLB (Bacterial Blight): Copper oxychloride 3g/L. No fungicide works!

Harvest Timing:
- Harvest when 80-85% of grains are golden yellow (straw colored).
- Usually 25-35 days after flowering/panicle emergence.
- Moisture at harvest: 20-22%. Dry to 12-14% before storage.
- Threshing delay beyond 3 days causes shattering losses.` },

  // ─── WHEAT ────────────────────────────────────────────────────────────────
  { tags: ["wheat", "wheat cultivation", "wheat farming", "wheat growing", "wheat fertilizer", "wheat nutrients", "gehu"],
    answer: `Wheat Cultivation Guide

Variety Selection (by region):
- Northwest India (Punjab, Haryana, UP): HD 2967, PBW 343, WH 542
- Central India (MP, Rajasthan): GW 322, HI 8498 (durum), K 0307
- Peninsular India: NW 1014, HD 2781

Sowing Time (Critical for Yield):
- Timely sowing: 1-15 November (north India), 15-30 November (central India).
- Late sowing after 15 December loses 1-1.5 quintal per hectare per day of delay!
- Use 10% higher seed rate for late sowing.

Seed Rate and Spacing:
- Seed rate: 100-125 kg per hectare for timely sowing.
- Late sowing: 125-150 kg per hectare.
- Row spacing: 22.5 cm. Seed depth: 5-6 cm.

Fertilizer (120-60-40 kg N-P-K per hectare):
Basal at sowing:
- 60 kg N + 60 kg P + 40 kg K + ZnSO4 25 kg if needed.
Top-dressing:
- At Crown Root Initiation (CRI) - first irrigation at 21 DAS: 60 kg N (130 kg urea). Most critical!

5 Critical Irrigations:
- 1st: CRI (21 DAS) - most important. Never miss this.
- 2nd: Tillering (45 DAS)
- 3rd: Jointing (65 DAS)
- 4th: Flowering (85 DAS)
- 5th: Grain filling (105 DAS)

Diseases:
- Yellow rust: Propiconazole 1ml/L at first sign.
- Brown rust: Tebuconazole 1ml/L.
- Powdery mildew: Sulphur 80WP 2.5g/L.
- Loose smut: Carboxin + Thiram 2.5g/kg seed treatment.

Harvest Timing:
- Harvest when grain moisture is 12-14% (straw golden yellow, grains hard).
- Late harvest causes shattering and quality loss.
- Combine harvesting saves 3-5% grain compared to manual.` },

  // ─── MAIZE ────────────────────────────────────────────────────────────────
  { tags: ["maize", "corn", "maize cultivation", "maize farming", "maize fertilizer", "makka"],
    answer: `Maize Cultivation Guide

Varieties:
- Hybrid varieties (recommended): DKC 9144, NK 6240, Dekalb 9108
- Open pollinated: Vikram, Amber, Sona (lower yield but cheaper seed)
- Baby corn: VL Baby Corn 1, IARI Baby Corn 1

Sowing:
- Kharif: June-July. Rabi: October-November (irrigated areas).
- Seed rate: 20-25 kg per hectare hybrid, 15-18 kg OPV.
- Spacing: 60x25 cm (rows x plants) for grain. 45x20 cm for baby corn.
- Seed treatment: Thiram 2g + Carbendazim 1g per kg seed.

Fertilizer (150-75-60 kg N-P-K per hectare):
Basal: 30 kg N + 75 kg P + 60 kg K
Top-dressing:
- At knee height (25-30 DAS): 60 kg N
- At tasseling/pre-flowering (45-50 DAS): 60 kg N

Critical Water Needs:
- Knee-height stage: First top-dressing + irrigation.
- Tasseling: Never miss. Yield loss is severe and permanent.
- Silking: Keep moisture consistent.

Fall Armyworm (Major Pest):
- Symptom: Ragged holes in whorl leaves with sawdust-like frass.
- Treatment: Emamectin benzoate 5SG at 0.4g/L sprayed into whorls in evening.

Harvest:
- Grain corn: Harvest when husks turn brown and grain moisture is below 25%.
- Baby corn: Harvest 1-3 days after silk emergence (before pollination). Harvest daily.` },

  // ─── ONION ────────────────────────────────────────────────────────────────
  { tags: ["onion", "onion cultivation", "onion farming", "onion growing", "onion fertilizer", "pyaz", "eerulli"],
    answer: `Onion Cultivation Guide

Varieties:
- Kharif varieties: Agrifound Dark Red, BSS 273, Bhaderwah Red
- Rabi varieties: Nasik Red, N-53, Agrifound Light Red, AFDR
- Long-day white varieties: Agrifound White, Pusa White Round (for export)

Nursery and Transplanting:
- Seed rate: 8-10 kg per hectare.
- Nursery: Raise for 40-45 days. Nursery area: 600-700 sq m per hectare.
- Transplant spacing: 15x10 cm (rows x plants) in flat beds or 15x7.5 cm on ridges.
- Plant at 2-3 cm depth. Deep planting causes elongated bulbs.

Fertilizer (100-50-50 kg N-P-K per hectare):
Basal: Full P + Full K + 30 kg N + FYM 25 tonnes per hectare.
Top-dressing:
- 30 days after transplanting: 35 kg N
- 50 days after transplanting: 35 kg N

Important: Stop nitrogen fertilization 30 days before harvest. Late nitrogen delays maturity, causes thick necks and poor storage quality.

Irrigation:
- Critical at bulb development stage (45-60 days after transplanting).
- Stop irrigation 10-12 days before harvest (when leaves fall over naturally).
- Over-irrigation at maturity = soft bulbs that rot in storage.

Harvest and Storage:
- Harvest when 50-70% of tops fall over naturally.
- Cure in shade for 7-10 days before storage.
- Store at ambient temperature with good airflow, or at 0-2°C for long-term.
- Avoid storing immediately after harvest without curing - causes sprouting and rotting.

Common Problems:
- Thrips: Spinosad 0.3ml/L or Fipronil 2ml/L. Very common and damaging.
- Purple blotch: Iprodione + Carbendazim spray. Dark purple lesions on leaves.
- Stemphylium blight: Mancozeb 2.5g/L + Chlorothalonil 2g/L.` },

  // ─── GROUNDNUT ────────────────────────────────────────────────────────────
  { tags: ["groundnut", "peanut", "groundnut cultivation", "groundnut farming", "groundnut fertilizer", "shengdana", "verusenaga"],
    answer: `Groundnut Cultivation Guide

Varieties:
- Bunch (erect) type: TAG-24, TG-38, K-6, TPG-41, GG-20 - short duration 100-110 days.
- Spreading type: M-13, Co-1, TMV-7 - longer duration, higher yield.
- Large seeded: GJG 9 for seeds/snack market.

Sowing:
- Kharif season: June-July (main season, rain-fed).
- Summer season: February-March (irrigated).
- Seed rate: 80-100 kg per hectare (shelled kernels).
- Remove seed coat just before sowing. Coat is fragile and cracks easily.
- Spacing: 30x10 cm. Seed depth: 4-5 cm (not deeper - pegs cannot penetrate if too deep).
- Seed treatment: Rhizobium 25g + Thiram 3g per kg seed.

Fertilizer (25-50-75 kg N-P-K per hectare):
Groundnut fixes its own nitrogen via Rhizobium bacteria. Low N needed!
Basal: 25 kg N + 50 kg P + 50 kg K + Gypsum 500 kg per hectare (calcium needed for peg development!).
Top-dressing at pegging: 25 kg K per hectare.

Gypsum (Calcium Sulphate) Application:
- Apply 500 kg per hectare at pegging (40-45 days after sowing).
- Critical for kernel development. Without calcium, empty pods form.

Irrigation:
- Critical at pegging (45 DAS) and pod development (65-75 DAS).
- Never irrigate just before harvest (causes aflatoxin contamination risk).

Leaf Spot Diseases (Most Common Problem):
- Early leaf spot (Cercospora): Round dark spots. Mancozeb 2.5g/L.
- Late leaf spot: Dark spots with lighter margin. Chlorothalonil 2g/L.
- Spray every 10-14 days from 30 DAS onwards.

Harvest:
- Harvest when 70-80% of pod interiors turn dark/black and kernel skin turns red-pink.
- Spread plants for 2-3 days in field to dry before threshing.
- Dry pods to below 8% moisture before storage.` },

  // ─── COTTON ───────────────────────────────────────────────────────────────
  { tags: ["cotton", "cotton cultivation", "cotton farming", "cotton growing", "cotton fertilizer", "cotton pest", "bollworm", "kapas", "hooge"],
    answer: `Cotton Cultivation Guide

Varieties:
- Bt Cotton Hybrids (recommended): Bollgard II varieties - NCS 145, RCH 659 BG II, MRC 7031 BG II.
- Non-Bt for non-bollworm areas: State-recommended varieties.
- Desi cotton: Suitable for organic farming, naturally resistant to some pests.

Sowing:
- Season: May-June in Kharif. Best sowing: 15 May to 15 June.
- Seed rate: 2.5-3 kg Bt hybrid per hectare.
- Spacing: 90x60 cm or 90x45 cm (rows x plants). Wider spacing in heavy black soils.
- Seed treatment: Imidacloprid 70WS 5g/kg for early sucking pest protection.

Fertilizer (150-75-75 kg N-P-K per hectare):
Basal: Full P + Full K + 50 kg N.
Top-dressing:
- At squaring (35-40 DAS): 50 kg N
- At boll development (65-70 DAS): 50 kg N

Key Pests of Cotton:
1. Bollworm (if Bt cotton used, most bollworm resistant): Emamectin 0.4g/L for heavy infestation.
2. Whitefly: Major pest! Spreads Leaf Curl Virus. Rotate: Imidacloprid → Acetamiprid → Spiromesifen.
3. Thrips: Fipronil 2ml/L or Spinosad 0.3ml/L.
4. Mealybug: Profenofos 2ml/L. Treat root zone if soil infestation.
5. Jassid/Leafhopper: Imidacloprid 0.25ml/L.

Boll Shedding Causes and Solutions:
- Heat above 40°C: Mulch and evening irrigation.
- Water stress at boll development: Irrigate immediately.
- Pest damage: Control jassids and thrips which cause boll shedding.

Harvest:
- Pick bolls when fully open (cotton fiber visible, 100% fluffy).
- Never pick wet cotton. Wait for morning dew to dry.
- Multiple pickings at 15-20 day intervals.` },

  // ─── SUGARCANE ────────────────────────────────────────────────────────────
  { tags: ["sugarcane", "sugarcane cultivation", "sugarcane farming", "sugarcane growing", "sugarcane fertilizer", "kabbu", "ganna"],
    answer: `Sugarcane Cultivation Guide

Varieties:
- Early maturing (10-12 months): CoJ 64, Co 0238, Co 86032 - high sugar, good for jaggery.
- Mid-late (14-18 months): Co 740, CoC 671 - high yield.
- Choose varieties recommended by your nearest sugar mill.

Planting:
- Seasons: Spring (Feb-Mar, best), Adsali (June-July), Preseasonal (October).
- Seed setts: Use 3-budded setts from 8-10 month old disease-free canes.
- Treat setts in Carbendazim 0.1% + Dithane M-45 0.25% for 30 minutes.
- Spacing: 90 cm row-to-row (paired row: 60+120 cm for better sunlight).
- Planting depth: 5-7 cm. Place setts end-to-end in furrow.
- Sett rate: 40,000-50,000 setts per hectare.

Fertilizer (250-115-115 kg N-P-K per hectare):
Basal: Full P + Full K + 50 kg N + FYM 25 tonnes per hectare.
Top-dressing:
- 30 days after planting: 100 kg N
- 90 days after planting: 100 kg N
- Ratoon crop (2nd year): 300 kg N + 100 kg P + 150 kg K per hectare.

Irrigation:
- Germination period (0-35 days): Light and frequent (every 7-10 days).
- Tillering (35-100 days): Every 10-15 days.
- Grand growth (100-270 days): Critical period! Every 7-10 days. Never stress.
- Maturity (270-360 days): Reduce and stop 45 days before harvest.

Common Diseases:
- Red Rot: Remove and destroy infected stools. No treatment. Use resistant varieties.
- Grassy shoot disease: Remove and destroy. Use healthy setts.
- Wilt: Improve drainage. Bordeaux mixture.

Harvest:
- Harvest at 12-14 months for maximum sugar recovery.
- Juice sucrose content should be 14%+ (check with refractometer).
- Ratoon crop (keeping the root for second year) saves replanting cost.` },

  // ─── BANANA ───────────────────────────────────────────────────────────────
  { tags: ["banana", "banana cultivation", "banana farming", "banana growing", "banana fertilizer", "bale", "kela"],
    answer: `Banana Cultivation Guide

Varieties:
- Grand Naine (Cavendish): Best for export, requires support at fruiting.
- Robusta: High yield, good for domestic market.
- Poovan (Mysore): Disease resistant, popular in south India.
- Red Banana (Karpooravalli): Niche and premium market.
- Nendran: Cooking banana, excellent in Kerala.

Planting:
- Best planting season: June-July or February-March.
- Planting material: Tissue culture plants (disease-free, uniform) or sword suckers.
- Spacing: 1.8x1.8 m or 2x2 m. High-density: 1.5x1.5 m.
- Pit size: 45x45x45 cm. Fill with topsoil + FYM 10 kg per pit.

Fertilizer Per Plant Per Year (Grand Naine):
- FYM: 10 kg at planting + 10 kg at bunch emergence.
- Urea: 200g in 5 split doses over 6 months.
- SSP: 100g as basal at planting.
- MOP: 300g in 3 split doses.
- Neem cake: 250g at planting (helps control nematodes).
- Boron 0.2% spray: At shooting and bunch development (prevents heart-rot).

Irrigation:
- Critical crop - needs consistent moisture, never waterlog.
- Drip irrigation recommended: 2 drippers per plant, 8-12 litres per plant per day.
- Mulching with dry leaves/grass reduces moisture need by 30%.

Common Problems:
- Panama Wilt (Fusarium): No cure. Destroy infected plants. Use resistant varieties and TC plants.
- Sigatoka leaf spot: Propiconazole 0.1% + Sticker spray every 3 weeks.
- Banana weevil: Apply Chlorpyriphos 20EC at suckers and soil at planting.
- Aphid/Banana aphid: Controls viral diseases - Imidacloprid 0.25ml/L.

Harvest:
- Harvest when fingers are 3/4 round (before ripening on plant).
- Cut entire bunch. Keep in shade, handle gently.
- Ripen with ethylene or simply keep in enclosed space at room temperature.` },

  // ─── POTATO ───────────────────────────────────────────────────────────────
  { tags: ["potato", "potato cultivation", "potato farming", "potato growing", "potato fertilizer", "aloo", "batata"],
    answer: `Potato Cultivation Guide

Varieties:
- Kufri Jyoti: All-purpose, good for chips and table use. Most common.
- Kufri Sindhuri: Red-skinned, good storage.
- Kufri Chipsona-1 and -2: Excellent for chips/crisps processing.
- Kufri Bahar: Good for table use, early maturing.

Seed and Planting:
- Use certified seed potato only! Avoid farm-saved seed for commercial crop.
- Seed rate: 25-35 quintals per hectare.
- Seed piece: 30-50g with 2-3 eyes. Let cut pieces dry 24 hours before planting.
- Treat seed: Mancozeb 0.3% + Carbendazim 0.1% dip for 10 minutes.
- Spacing: 60x20 cm or 50x20 cm (rows x plants). Ridges or flatbed.
- Planting time: October-November (north India), December-January (south India).

Fertilizer (200-150-150 kg N-P-K per hectare):
This is the highest fertilizer requirement crop!
Basal: Full P + Full K + 75 kg N + FYM 25 tonnes per hectare + ZnSO4 25 kg.
Top-dressing:
- At earthing up (30-35 DAS): 75 kg N
- At tuber initiation (45-50 DAS): 50 kg N

Earthing Up (Critical):
- Must do at 30-35 DAS. Pull soil around base of plants into ridges.
- Prevents greening of tubers (green tubers are toxic and unsaleable).

Late Blight (Most Serious Threat):
- Appears as dark water-soaked patches on leaves with white mold below.
- EMERGENCY spray: Cymoxanil + Mancozeb 3g/L immediately.
- Preventive spray: Mancozeb 2.5g/L every 7-10 days when conditions are cool and humid.

Harvest:
- Harvest 70-90 days after planting when tops start dying.
- Haulm kill (cut/spray tops) 2 weeks before harvest to harden skin.
- Skin test: Rub thumb on tuber skin. If skin doesn't peel, tubers are ready.
- Store at 4-6°C for long-term or in cool, dark, ventilated room for short-term.` },

  // ─── DISEASES GENERAL ─────────────────────────────────────────────────────
  { tags: ["disease", "plant disease", "crop disease", "disease symptoms", "disease treatment", "disease control", "fungal disease", "bacterial disease", "viral disease"],
    answer: `Crop Disease Identification and Control

Identify Disease Type First - Treatment Differs Completely:

FUNGAL DISEASES (most common):
- Appearance: Powdery coatings, rust pustules, leaf spots with defined borders, mold, blights.
- Treatment: Fungicides work well.
  - Protectants (prevent entry): Mancozeb, Chlorothalonil, Copper oxychloride.
  - Systemics (kill inside plant): Propiconazole, Tebuconazole, Hexaconazole, Carbendazim.
- Promoted by: High humidity, wet weather, poor air circulation.

BACTERIAL DISEASES:
- Appearance: Water-soaked lesions, angular spots bounded by leaf veins, ooze from cut stem, foul smell, wilting.
- Treatment: Fungicides do NOT work! Use Copper oxychloride 3g/L or Streptocycline 500ppm + Copper.
- Very limited chemical options. Prevention is the key.

VIRAL DISEASES:
- Appearance: Mosaic patterns (light/dark patches), leaf curl or distortion, ring spots, stunting.
- Treatment: NO chemical cure exists. Control the insect vector that spreads the virus.
- Prevention: Use resistant varieties, control vectors (aphid/whitefly/thrips), remove infected plants immediately.

Quick Symptom Guide:
- Target/ring spots on leaves: Alternaria blight. Use Mancozeb 2.5g/L.
- Diamond-shaped grey spots: Blast (rice). Use Tricyclazole 0.6g/L.
- Yellow stripe pustules: Rust. Use Propiconazole 1ml/L.
- White powder on surface: Powdery mildew. Use Sulphur 80WP 2.5g/L.
- Leaves curl upward + whitefly: Leaf curl virus. Control vector.
- Seedling collapse at soil level: Damping off. Drench Carbendazim 1g/L.
- Plant wilts even when watered: Fusarium wilt. Remove plant, apply Trichoderma.
- Water-soaked black/brown patch spreading fast: Late blight. Spray Metalaxyl + Mancozeb immediately.` },

  // ─── RICE BLAST ───────────────────────────────────────────────────────────
  { tags: ["rice blast", "blast", "blast disease", "neck blast", "neck rot", "leaf blast", "rice fungus"],
    answer: `Rice Blast Disease (Magnaporthe oryzae)

Symptoms:
- Leaf blast: Diamond-shaped grey-white lesions with brown borders on leaves.
- Neck blast: Panicle neck turns brown-black causing "white ear" (empty panicle with no grain).
- Node blast: Girdling lesions on stem nodes causing lodging.

Conditions That Favor Blast:
- Cool nights (20-22°C), warm days, humidity above 90%, excess nitrogen.

Treatment (Act Within 24 Hours of First Symptom):
- Tricyclazole 75WP: 0.6g per litre (best choice, systemic).
- Azoxystrobin 23SC: 1ml per litre (excellent for neck blast).
- Carbendazim 50WP: 1g per litre.
- Repeat after 10 days. Spray in early morning or evening.

Prevention:
- Resistant varieties: IR-36, IR-64, Samba Mahsuri, Pusa Basmati-1.
- Balanced NPK. Never over-apply nitrogen at panicle initiation stage.
- Seed treatment: Carbendazim 2g per kg before sowing.
- Remove all infected crop debris after harvest.` },

  // ─── RUST DISEASES ────────────────────────────────────────────────────────
  { tags: ["rust", "yellow rust", "stripe rust", "brown rust", "stem rust", "rust disease", "rust treatment", "rust on plant", "tukku", "plant rust"],
    answer: `Rust Diseases - Complete Guide

Types of Rust:

Yellow/Stripe Rust (Puccinia striiformis):
- Yellow-orange pustules arranged in stripes along leaf length.
- Cool weather 10-15°C with high humidity. Common February-March in north India hills.

Brown/Leaf Rust (Puccinia triticina):
- Round orange-brown pustules randomly scattered on upper leaf surface.
- Most common wheat rust in India. Moderate temperature 15-22°C.

Stem/Black Rust (Puccinia graminis):
- Dark brick-red to black pustules on stems and leaf sheaths.
- Most destructive type. Can cause complete crop collapse.

Rust on Other Crops:
- Groundnut rust: Orange pustules on leaf underside. Chlorothalonil 2g/L.
- Soybean rust: Tan-brown pustules on underside. Tebuconazole 1ml/L.
- Bean rust: Reddish-brown pustules. Mancozeb 2.5g/L.

Treatment for All Rust Types:
- Propiconazole 25EC: 1ml per litre (best systemic, controls all rust types).
- Tebuconazole 25.9EC: 1ml per litre.
- Mancozeb 75WP: 2.5g per litre (protectant only, less effective on established rust).
- Apply at FIRST sign. Usually 1-2 well-timed sprays give good control.

Prevention:
- Rust-resistant wheat varieties: HD 2967, PBW 343.
- Timely sowing (October-November for wheat).
- Avoid excess nitrogen fertilization.` },

  // ─── APHIDS ───────────────────────────────────────────────────────────────
  { tags: ["aphid", "aphids", "sucking pest", "mahu", "green fly", "black fly", "plant lice"],
    answer: `Aphid Control Guide

What Are Aphids?
Small soft insects (1-3 mm), green, black, yellow or brown. Found in dense colonies on young leaves, shoot tips, flower buds. Excrete sticky honeydew causing black sooty mold.

Why Dangerous:
- Direct feeding: Stunting, curling leaves, reduced photosynthesis.
- Virus transmission: Aphids spread PLRV in potato, CMV in cucurbits, BYDV in wheat. Often more damaging than feeding!

Natural Enemies (Conserve These - They Are Free):
- Ladybird beetles: One adult eats 200 aphids per day.
- Lacewings, hoverfly larvae, parasitic wasps.
- Strong water jet in morning dislodges colonies.

Organic Control:
- Neem oil 5ml/L + liquid soap 2ml/L.
- Garlic spray: Blend 50g garlic in 1L water, dilute 1:10, spray.
- Chilli extract: 100g dried chilli in 1L, strain, dilute 1:5 and spray.

Chemical Control (Spray Only When Threshold Reached):
- Threshold: 30+ aphids per tiller, or 30% leaves infested.
- Imidacloprid 17.8SL: 0.25ml per litre (systemic, long lasting).
- Dimethoate 30EC: 2ml per litre.
- Thiamethoxam 25WG: 0.3g per litre.
- Never spray when ladybirds are actively visible.` },

  // ─── PEST MANAGEMENT ─────────────────────────────────────────────────────
  { tags: ["pest", "pest control", "ipm", "insecticide", "pesticide", "pest management", "biological control", "spray schedule"],
    answer: `Integrated Pest Management (IPM) - Complete System

Economic Thresholds (Spray Only When These Are Crossed):
- Rice stem borer: 10% dead heart
- Cotton bollworm: 2 eggs or 1 larva per 10 plants
- Wheat aphid: 30+ aphids per tiller
- Soybean pod borer: 1-2 larvae per plant
- Never spray below threshold - wastes money and kills natural enemies!

Step 1 - MONITORING:
- Scout twice weekly in early morning.
- Pheromone traps: 5 per acre, replace lure monthly.
- Yellow sticky traps for whitefly and aphid monitoring.
- Keep written records of pest and beneficial counts.

Step 2 - CULTURAL CONTROL:
- Crop rotation breaks pest cycles.
- Resistant and tolerant varieties (first defense).
- Correct sowing date and plant density.
- Summer deep plowing exposes and kills soil pests.
- Remove crop residues after harvest.

Step 3 - BIOLOGICAL CONTROL:
- Trichogramma (egg parasite): 50,000/acre against stem borer, bollworm.
- Bt spray 1 kg/ha: Against all caterpillars at young stage.
- Trichoderma viride: Against soil fungi.
- Beauveria bassiana: Against thrips, whitefly, beetles.

Step 4 - CHEMICAL (If Threshold Crossed):
- Choose selective, low-residue products.
- Rotate chemical classes every spray to prevent resistance.
- Follow Pre-Harvest Interval (PHI) on label strictly.
- Spray early morning or evening. Never in hot afternoon.` },

  // ─── MICRONUTRIENTS ───────────────────────────────────────────────────────
  { tags: ["zinc deficiency", "iron deficiency", "boron deficiency", "micronutrient", "yellowing", "khaira", "deficiency", "calcium deficiency", "magnesium deficiency"],
    answer: `Micronutrient Deficiency Guide

ZINC (Most Common Deficiency in India - 50% of soils are zinc deficient):
- Crops most affected: Rice, wheat, maize, citrus.
- Signs: Khaira disease in rice (reddish-brown spots, white midrib streak, stunted bushy plants). In other crops: small distorted leaves, poor growth.
- Soil fix: ZnSO4 25 kg/ha as basal application.
- Foliar fix (faster): ZnSO4 5g/L spray, repeat twice at 15-day intervals.

IRON:
- Signs: Yellowing between veins in YOUNG/new leaves (veins remain green). Older leaves stay green.
- Fix: FeSO4 5g/L + Citric Acid 2.5g/L foliar spray. (Citric acid keeps iron soluble in the spray.) Repeat 3 times at 7-day intervals.

BORON:
- Signs: Hollow stems in cabbage/broccoli, poor/zero fruit set, cracked fruit skin, empty sunflower heads, die-back of growing tip.
- Soil fix: Borax 10-15 kg/ha as basal.
- Foliar fix: Borax 2g/L at pre-flowering stage.
- WARNING: Do not over-apply. Boron toxicity is harmful.

CALCIUM:
- Signs: Blossom End Rot (black/brown sunken patch on bottom of tomato/capsicum), tip burn in lettuce, bitter pit in apple, hollow broccoli stem.
- Fix: Calcium Nitrate 10g/L foliar spray at fruiting. Keep soil moisture consistent.

MAGNESIUM:
- Signs: Yellow patches between veins of OLD/lower leaves (unlike iron which affects young leaves).
- Fix: MgSO4 (Epsom salt) 20g/L foliar spray OR 50 kg/ha soil application.

SULPHUR:
- Signs: Yellowing of young leaves (looks like nitrogen deficiency but starts from top).
- Fix: Use SSP instead of DAP for phosphorus (SSP contains 12% sulphur). Or apply Gypsum 200 kg/ha.` },

  // ─── ORGANIC FARMING ──────────────────────────────────────────────────────
  { tags: ["organic", "natural farming", "jeevamrut", "beejamrut", "zero budget", "biofertilizer", "jaivik", "organic farming"],
    answer: `Organic and Natural Farming Guide

Zero Budget Natural Farming (ZBNF) - Subhash Palekar Method:

1. Beejamrut (Seed Treatment):
   - Mix: 5g desi cow dung + 5ml cow urine + 2g lime in 1 litre water.
   - Soak seeds 6 hours before sowing. Protects against soil fungi and improves germination.

2. Jeevamrut (Soil Microbial Booster):
   - 10 kg cow dung + 10L cow urine + 2 kg jaggery + 2 kg legume flour + 1 handful forest soil.
   - Add to 200 litres water. Ferment 48 hours in shade, stir twice daily.
   - Apply 200 litres per acre per month through drip or by spraying in field.

3. Mulching (Acchadana): 2-3 inch layer of any dry biomass or crop residue on soil.

4. Waaphasa: Keep soil at 50% moisture and 50% air. Avoid waterlogging.

Biofertilizers (Recommended for Every Crop):
- Rhizobium: For all legumes (gram, soybean, groundnut, tur). 25g per kg seed. Fixes 100-200 kg N/ha free from air!
- Azospirillum: For cereals (rice, wheat, maize, sorghum). 25g per kg seed. Saves 20% nitrogen fertilizer.
- PSB (Phosphate Solubilizing Bacteria): For all crops. 2 kg/ha. Saves 25% phosphorus fertilizer.
- Mycorrhiza (VAM): All crops. Greatly improves water and nutrient uptake. 5 kg/ha.
- RULE: Always apply biofertilizer LAST, after all chemical seed treatments. Never mix with chemicals directly.

Organic Pest Control:
- Neem oil 5ml/L: Broad-spectrum insect and fungal control.
- Neem cake 250 kg/ha soil application: Controls soil pests and nematodes.
- Bt spray 1 kg/ha: Safe caterpillar control, harmless to humans and beneficial insects.
- Beauveria bassiana: Against thrips, whitefly, beetles.` },

  // ─── GOVERNMENT SCHEMES ───────────────────────────────────────────────────
  { tags: ["government scheme", "subsidy", "pm kisan", "pmfby", "kcc", "loan", "crop insurance", "sarkari yojana", "government help", "kisan"],
    answer: `Government Schemes for Farmers

PM-KISAN (Direct Income Support):
- Benefit: Rs 6,000 per year in 3 instalments of Rs 2,000 each.
- Who gets it: All landholding farmer families.
- Register: pmkisan.gov.in or nearest CSC centre.
- Helpline: 155261

PM Fasal Bima Yojana (PMFBY - Crop Insurance):
- Premium: Only 1.5% for rabi, 2% for kharif. Government pays the rest (10-25%).
- Covers: Natural disasters, pests, diseases, prevented sowing, post-harvest (14 days).
- How to enroll: Through bank with crop loan OR directly through CSC before deadline.
- Helpline: 1800-200-7710 (Toll Free)

Kisan Credit Card (KCC - Easy Farm Credit):
- Loan up to Rs 3 lakh at only 4% effective interest per year.
- Use for: Seeds, fertilizers, pesticides, labour, irrigation costs.
- Apply at any bank or cooperative bank with land records.

PM Krishi Sinchai Yojana (PMKSY - Irrigation Subsidy):
- Drip irrigation: 55-90% subsidy (higher for small, marginal, SC/ST farmers).
- Apply at State Horticulture Department.

Soil Health Card:
- Free soil testing with printed crop-wise recommendations.
- Apply at Block Agriculture Office or soilhealth.dac.gov.in.

ATMA Scheme:
- Free training, exposure tours, farm demonstrations.
- Contact Block Technology Manager at Block Agriculture Office.

Kisan Call Centre: 1800-180-1551 (Free, all days, 6AM-10PM, 22 Indian languages)` },

  // ─── POST HARVEST ─────────────────────────────────────────────────────────
  { tags: ["post harvest", "storage", "grain storage", "cold storage", "after harvest", "storing", "preserve", "warehouse"],
    answer: `Post-Harvest Management - Reduce Losses, Increase Income

Grain Drying and Storage:
1. Dry grain to safe moisture: Paddy below 14% (ideally 12%), wheat below 12%, pulses below 9%.
2. Use grain moisture meter (Rs 500-1,500) - critical investment.
3. Hermetic bags (PICS/GrainPro): Airtight, no pesticide needed, controls all insects and mold for 1-2 years. Rs 100-150/50kg bag.
4. Metal bins (Pusa bins): Mouse-proof, long-term storage.
5. Jute bags: Apply Malathion 5% dust at 500g per tonne of grain.

Fruits and Vegetables (25-40% losses possible without proper handling):
1. Harvest in early morning when cool.
2. Handle gently. Do NOT drop crates. Bruised spots rot first.
3. Grade by size and quality. Grade A gets 15-25% premium at mandi.
4. Shade cooling immediately after harvest extends shelf life by 50-100%.
5. Pack in ventilated corrugated boxes. Avoid plastic bags.

Cold Storage Temperatures:
- Potato: 4-6°C, 90-95% humidity. Stores up to 9 months.
- Tomato: 8-12°C. Below 8°C causes chilling injury.
- Onion: 0-2°C, OR ambient with very good ventilation.
- Mango (green): 13°C extends season by 4-6 weeks.
- Banana: 12-14°C prevents ripening.

Value Addition to Earn More:
- Tomatoes into puree or ketchup: 3x price.
- Amla into candy or juice: 5-7x price.
- Turmeric dried and ground: 3-4x price of fresh rhizome.
- Community cold stores: Contact Agriculture Department for nearest facility.` },

  // ─── HARVEST TIMING ───────────────────────────────────────────────────────
  { tags: ["harvest", "when to harvest", "maturity", "harvest time", "harvesting", "ready to harvest", "cutting", "picking"],
    answer: `Crop Harvest Timing Guide

When Is the Crop Ready to Harvest?

RICE (Paddy):
- 80-85% of grains golden yellow (straw colored).
- 25-35 days after flowering.
- Grain moisture 20-22%. Dry to 12-14% before storage.

WHEAT:
- All plants golden yellow, grain hard when bitten.
- Grain moisture 12-14%.
- Do not delay - shattering increases 1-2% per day after full maturity.

MAIZE (Grain):
- Husks turn brown and dry, kernels dent on top.
- Grain moisture below 25%.
- Black layer visible at base of kernel.

TOMATO:
- Breaker stage (just starting to turn red): For distant markets (withstands transport).
- Full red: For local market or home use.

ONION:
- 50-70% of tops (leaves) naturally fall over.
- Pull one bulb and check neck is tight, not soft.
- Stop irrigation 10-12 days before harvest.

POTATO:
- Tops turn yellow and begin to die naturally.
- Rub thumbnail on tuber skin - if skin does not peel, tubers are mature.
- Haulm kill 2 weeks before harvest helps harden skin.

GROUNDNUT:
- 70-80% of pod interiors turn dark/black.
- Kernel skin turns pink-red.
- Test: Pull a few plants and examine pods.

COTTON:
- Bolls fully open with white fluffy fiber visible.
- Pick only fully opened bolls. Never pick wet cotton.

SUGARCANE:
- 12-14 months after planting.
- Juice sucrose content above 14% (test with refractometer).
- Top leaves show yellowing and drying.` },

  // ─── SOWING AND SPACING ───────────────────────────────────────────────────
  { tags: ["sowing", "planting", "transplanting", "spacing", "seed rate", "when to sow", "when to plant", "plant spacing", "row spacing", "plant density"],
    answer: `Sowing and Planting Guide

Recommended Seed Rates:
- Rice (transplanting): 20-25 kg per hectare
- Rice (direct seeding): 60-80 kg per hectare
- Wheat: 100-125 kg per hectare (timely); 125-150 kg (late sowing)
- Maize (hybrid): 20-25 kg per hectare
- Cotton (Bt hybrid): 2.5-3 kg per hectare
- Tomato: 250-400g per hectare (raise nursery)
- Onion: 8-10 kg per hectare (raise nursery)
- Groundnut: 80-100 kg per hectare (shelled kernels)
- Soybean: 70-80 kg per hectare
- Sugarcane: 40,000-50,000 setts (3-bud) per hectare

Recommended Plant Spacing:
- Rice: 20x15 cm (rows x plants)
- Wheat: 22.5 cm between rows (drill sowing)
- Maize (grain): 60x25 cm
- Tomato: 60x45 cm or 45x60 cm
- Brinjal: 60x60 cm
- Lady's Finger: 60x30 cm
- Cotton: 90x60 cm or 90x45 cm
- Onion: 15x10 cm
- Potato: 60x20 cm
- Sugarcane: 90 cm between rows (single), 60+120 cm (paired rows)
- Banana: 1.8x1.8 m or 2x2 m

Best Sowing Dates:
- Rice Kharif: June-July
- Wheat: 1 November to 15 November (timely); never after 15 December
- Cotton: 15 May to 15 June
- Soybean: June 20 to July 10
- Chickpea: October-November
- Mustard: September-October (hills), October-November (plains)` },

  // ─── WEED MANAGEMENT ─────────────────────────────────────────────────────
  { tags: ["weed", "weed control", "herbicide", "weeding", "kale", "grass weed", "broadleaf weed"],
    answer: `Weed Management Guide

Critical Weed-Free Period:
- Crops must be weed-free for first 30-45 days. Weeds during this period cause 40-80% yield loss.
- After crop canopy closes, weeds matter much less.

Control Methods:

1. PREVENTIVE: Certified weed-free seed, fully composted FYM (heat kills weed seeds), clean equipment.

2. CULTURAL: Narrow row spacing for faster canopy closure, mulching (controls 70-80% weeds), crop rotation.

3. MECHANICAL: Hand weeding at 20-25 DAS most critical. Power weeder at 0.5-1 acre/hour.

4. CHEMICAL HERBICIDES:
   Rice:
   - Pre-emergence (3-5 DAS): Pretilachlor 50EC at 1L/ha.
   - Post-emergence (15-20 DAS): Bispyribac-sodium 10SC at 200ml/ha.

   Wheat:
   - Grassy weeds (wild oat, Phalaris): Clodinafop-propargyl 15WP at 400g/ha at 30-35 DAS.
   - Broadleaf weeds: 2,4-D Sodium 80WP at 1kg/ha at 30-35 DAS.

   Maize: Atrazine 50WP at 1.5 kg/ha pre-emergence.
   Soybean: Pendimethalin 30EC at 1L/ha pre-emergence.
   Cotton: Pendimethalin at 1-1.5L/ha pre-emergence.

   DANGER: NEVER use 2,4-D near tomato, brinjal, cucumber, grapes, or any broad-leaf vegetable. Severe irreversible damage results even from drift.` },

  // ─── SAFETY ───────────────────────────────────────────────────────────────
  { tags: ["safety", "precaution", "pesticide safety", "farm safety", "snake bite", "lightning", "ppe", "safe spraying"],
    answer: `Farm Safety and Precautions

Pesticide Safety (Most Important):
- Read the full label before opening any container.
- Always wear: Rubber gloves, face mask/respirator, goggles, full-body clothing.
- Mix outdoors in ventilated area. Never inside your home.
- Best spray time: 6-9 AM or 4-6 PM. Never in hot afternoon.
- Stop immediately if wind picks up.
- Never eat, drink or smoke while spraying.
- Skin contact: Wash with soap and water for 15 minutes.
- Eye contact: Flush with clean water for 20 minutes. See a doctor.
- Swallowed: Hospital immediately with the label or container.
- Store locked, separately from food, away from children.

Weather Safety:
- Lightning: Leave field when dark clouds approach. Do NOT shelter under trees. Go to a solid building. Download Damini app for alerts.
- Heat wave: Work only 6-10 AM and 5-7 PM, wear light cotton clothes, rest in shade 11 AM-3 PM. Carry water.
- Flood: Do not walk through flooded fields. Risk of electrocution and snake bites.

Snake Bite Prevention and Response:
- Prevention: Rubber boots in field, especially at sowing and harvest. Torch when working at dawn/dusk.
- If bitten: Stay calm. Immobilize bitten limb. Go to hospital IMMEDIATELY. Do NOT cut, suck, or tie tight tourniquet.

Equipment Safety:
- Tractor PTO shaft: Always keep safety guard in place. Never step over rotating shaft. Loose clothing is fatal.
- Thresher: Never put hand inside while running. Always stop completely before clearing blockage.` },

  // ─── MUSHROOM ─────────────────────────────────────────────────────────────
  { tags: ["mushroom", "mushroom cultivation", "oyster mushroom", "mushroom farming", "mushroom growing"],
    answer: `Mushroom Cultivation - Complete Guide

Why Mushrooms?
- No land required, grown indoors.
- Price: Rs 80-200/kg for oyster, Rs 100-250/kg for milky mushroom.
- 10-15 crop cycles per year.
- Uses agricultural waste (paddy straw, wheat straw, cotton stalks).

Growing Steps for Oyster Mushroom:
1. Chop paddy straw into 5-8 cm pieces.
2. Pasteurize: Soak in hot water at 80°C for 1 hour. OR Soak in Carbendazim 0.1% + Formalin 0.3% for 18 hours. Drain and air for 24 hours.
3. Pack in polythene bag: Layer straw (4 inches) then spawn (mushroom seed) - 200g spawn per 3 kg dry straw.
4. Seal bag. Keep in dark room at 25-28°C for 15-20 days until white mycelium covers straw.
5. Cut holes when pins emerge. Move to ventilated, humid room (80-90% humidity) with indirect light.
6. Harvest when caps fully open (3-5 days after pin appearance).
7. Expect 3 flushes per bag over 45-60 days.

Contact nearest KVK for spawn supply and free training.` },

  // ─── LIVESTOCK ────────────────────────────────────────────────────────────
  { tags: ["livestock", "cattle", "cow", "goat", "poultry", "dairy", "milk", "animal husbandry", "integrated farming"],
    answer: `Integrated Livestock and Crop Farming

Dairy Farming with Crops:
- 2 HF or Jersey crossbred cows: 20-25 litres milk/day.
- Feed 40% from farm by-products: green fodder, straw, wheat bran.
- Best fodder crops: Napier grass CO-4, Berseem (winter), Maize/Sorghum (summer).
- Sell milk: Join local dairy cooperative (AMUL, Mother Dairy, KMF). Daily collection.
- KCC covers dairy loans. NABARD gives subsidy for dairy units.

Goat Farming:
- Low investment, low risk, high stable demand (meat and milk).
- Good breeds: Beetal, Sirohi, Barbari (dual purpose).
- Start with 10 does + 1 buck. Scale from profits.
- Annual vaccination: FMD, Enterotoxemia (ET), PPR - essential.
- Feed: Browse (shrubs/leaves), crop residues, mineral supplement.

Biogas Plant (2 cows = 1 family's cooking fuel):
- 2 cubic meter plant: Rs 15,000-20,000 (government subsidy available).
- Saves Rs 500-700/month on LPG.
- Slurry output: Excellent liquid organic manure.

Poultry with Crops:
- Backyard poultry (Kadaknath, Desi breeds): Low input, high market price.
- Eggs: Rs 6-10 per egg for desi breeds vs Rs 4-5 for white commercial.
- Free-range birds also eat insects and pests in the field.` },

  // ─── SEEDS ────────────────────────────────────────────────────────────────
  { tags: ["seed", "seed selection", "hybrid seed", "variety", "certified seed", "seed treatment", "seed quality", "beeja"],
    answer: `Seed Selection and Treatment

Hybrid vs Open Pollinated Varieties (OPV):

Hybrid Seeds:
- 20-30% higher yield, uniform crop, better disease resistance.
- Seeds cannot be saved for next season (loss of hybrid vigour).
- Cost: Rs 300-1,500 per packet.
- Best for: Commercial farming with good market linkage.

Open Pollinated Varieties (OPV):
- Seeds can be saved 3-4 seasons (big cost saving).
- 10-20% lower yield than hybrids.
- Adapted to local conditions over years.
- Best for: Subsistence farming, organic farming, traditional varieties.

Buying Quality Seed:
- Always buy BIS-certified seed (mandatory tag attached to bag).
- Check germination %: Rice 80%+, Wheat 85%+, Vegetables 70%+.
- Moisture below 12% for safe storage.
- Purchase from government seed corporations or registered dealers only.
- Avoid buying cheap unmarked seed - may be spurious.

Seed Treatment (Do This Before Every Sowing):
Apply in this strict order, let each layer dry before next:
1. Trichoderma viride 4g per kg seed (biological fungicide against soil diseases)
2. Thiram 2g + Carbendazim 1g per kg (chemical fungicide for seed-borne pathogens)
3. Imidacloprid 70WS 5g per kg (against early sucking pests and virus vectors)
4. Rhizobium or Azospirillum 25g per kg (biofertilizer - ALWAYS APPLY LAST)

Home Seed Viability Test:
- Take 10 seeds, place on wet cloth in warm place for 5-7 days.
- Count germinated seeds. 8/10 = 80% germination = acceptable.
- Adjust seed rate if germination is below 75%.` },

  // ─── SMART FARMING ────────────────────────────────────────────────────────
  { tags: ["smart farming", "digital farming", "drone", "farming app", "technology", "precision farming", "plantix", "kisan app"],
    answer: `Smart Farming Technologies

Must-Have Free Apps:
1. Plantix: Take photo of diseased plant, app identifies disease and suggests treatment instantly. Covers 400+ crop problems in Hindi, Kannada, Telugu, Tamil. Download immediately!
2. Kisan Suvidha: Weather, mandi prices, expert advice in one place. By Government of India.
3. Meghdoot (IMD): 5-day agro-weather forecast at block level, crop-specific.
4. eNAM: Live mandi prices. Online produce registration and bidding.
5. mFarm/Fasal: AI crop advisory with disease alerts and irrigation scheduling.

Drone Technology:
- Spraying: 8-10 acres per hour vs 0.5 acres/hour manually.
- Hire cost: Rs 350-500 per acre.
- Benefits: 85% less water, uniform coverage, works on tall crops.
- Find service: FPOs, agri-service centers, state government programs.

Soil Sensors:
- Soil moisture sensors: Rs 3,000-8,000. Real-time data on mobile.
- Automatic drip irrigation controller: Rs 5,000-15,000.

Start simple: Install Plantix for disease detection and Kisan Suvidha for weather. These two free apps alone can save thousands of rupees per season.` },

];

// ════════════════════════════════════════════════════════════════════════════
//  SMART SEARCH ENGINE - Whole-word matching, minimum score threshold
// ════════════════════════════════════════════════════════════════════════════
function tokenize(text) {
  return text.toLowerCase()
    .replace(/[?।,!.;:'"\-_()]/g, " ")
    .split(/\s+/)
    .filter(w => w.length > 2);
}

function searchKnowledge(query) {
  const queryWords = tokenize(query);
  if (queryWords.length === 0) return null;

  const scores = KB.map(entry => {
    let score = 0;

    for (const tag of entry.tags) {
      const tagWords = tokenize(tag);

      // Check if the full tag phrase appears in the query (exact phrase match) - highest score
      if (query.toLowerCase().includes(tag.toLowerCase())) {
        score += tagWords.length * 10;  // 10 pts per word in matched phrase
        continue;
      }

      // Count how many tag words appear as whole words in the query
      let wordOverlap = 0;
      for (const tw of tagWords) {
        for (const qw of queryWords) {
          if (qw === tw) { wordOverlap++; break; }  // exact word match only
        }
      }
      if (wordOverlap > 0) score += wordOverlap * 4;
    }

    return { entry, score };
  });

  const sorted = scores.sort((a, b) => b.score - a.score);
  const best = sorted[0];

  // Minimum threshold: must score at least 4 (one solid word match) to return a result
  if (!best || best.score < 4) return null;
  return best.entry;
}

const FALLBACK_MSG = `I couldn't find a specific answer to your question in my knowledge base.

For an immediate expert answer, please call:
Kisan Call Centre: 1800-180-1551 (Free, all days, 6AM-10PM, available in your language)

OR use these apps:
- Plantix (take a photo of the affected plant - identifies diseases instantly)
- Kisan Suvidha (weather, market prices, expert advice)

Topics I can answer:
- Crop cultivation (rice, wheat, maize, tomato, onion, potato, cotton, sugarcane, groundnut, banana)
- Fertilizer doses for each crop
- Crop diseases and treatment
- Irrigation scheduling
- Weed control
- Pest management
- Market prices and MSP
- Government schemes (PM-KISAN, PMFBY, KCC)
- Soil testing and soil types
- Organic and natural farming
- Post-harvest storage
- Farm safety
- When to harvest each crop
- Sowing time and seed rates`;

// ════════════════════════════════════════════════════════════════════════════
//  MAIN REPLY BUILDER
//  1. Translate user query → English
//  2. Search KB
//  3. Translate answer → user's language
// ════════════════════════════════════════════════════════════════════════════
async function buildReply(messages, lang) {
  const lastUser = [...messages].reverse().find(m => m.role === "user");
  if (!lastUser) {
    const hello = "Hello! I am AgroBot, your complete farming assistant. Ask me any farming question!";
    return lang === "en" ? hello : await gtranslate(hello, "en", lang);
  }

  // Step 1: Translate query to English for KB search
  const queryInEnglish = lang === "en"
    ? lastUser.content
    : await gtranslate(lastUser.content, lang, "en");

  // Step 2: Search knowledge base with English query
  const match = searchKnowledge(queryInEnglish);
  const englishAnswer = match ? match.answer : FALLBACK_MSG;

  // Step 3: Translate answer to user's selected language
  if (lang === "en") return englishAnswer;
  return await translateLong(englishAnswer, lang);
}

// ─── Express Route ────────────────────────────────────────────────────────────
router.post("/", async (req, res) => {
  const { messages, language = "en" } = req.body;
  if (!Array.isArray(messages) || messages.length === 0)
    return res.status(400).json({ error: "messages array required" });

  const langName = LANG_NAMES[language] ?? "English";

  // Try OpenAI if a valid key is configured
  if (process.env.OPENAI_API_KEY?.trim() && process.env.OPENAI_API_KEY !== "your_openai_api_key_here") {
    try {
      const { default: OpenAI } = await import("openai");
      const client = new OpenAI({ baseURL: process.env.OPENAI_BASE_URL, apiKey: process.env.OPENAI_API_KEY });
      const valid = messages.filter(m => m && typeof m.role === "string" && typeof m.content === "string");
      const r = await client.chat.completions.create({
        model: process.env.OPENAI_MODEL || "gpt-4o-mini",
        messages: [
          { role: "system", content: `You are AgroBot, an expert agricultural assistant for Indian farmers. Answer all farming questions. Respond entirely in ${langName}.` },
          ...valid,
        ],
        max_tokens: 1000,
      });
      return res.json({ reply: r.choices[0]?.message?.content ?? "No response." });
    } catch (err) {
      if (!(err?.status === 401 || err?.status === 429 || err?.status === 503))
        return res.status(err?.status >= 400 ? err.status : 500).json({ error: err.message });
    }
  }

  // Knowledge base + Google Translate (no API key needed)
  const reply = await buildReply(messages, language);
  res.json({ reply, source: "knowledge_base" });
});

export default router;
