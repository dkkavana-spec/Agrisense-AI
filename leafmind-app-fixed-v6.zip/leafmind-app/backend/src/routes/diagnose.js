import { Router } from "express";
import "dotenv/config";

const router = Router();

const LANG_NAMES = {
  en: "English", hi: "Hindi", kn: "Kannada", te: "Telugu",
  ta: "Tamil",   mr: "Marathi", bn: "Bengali", gu: "Gujarati", pa: "Punjabi"
};
const LANG_CODES = {
  en: "en", hi: "hi", kn: "kn", te: "te",
  ta: "ta", mr: "mr", bn: "bn", gu: "gu", pa: "pa"
};

async function gtranslate(text, targetLang) {
  if (!text || !text.trim() || targetLang === "en") return text;
  try {
    const tl  = LANG_CODES[targetLang] || "en";
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=${tl}&dt=t&q=${encodeURIComponent(text)}`;
    const res = await fetch(url, {
      headers: { "User-Agent": "Mozilla/5.0" },
      signal: AbortSignal.timeout(12000),
    });
    if (!res.ok) return text;
    const data = await res.json();
    if (!Array.isArray(data?.[0])) return text;
    return data[0].map(s => (Array.isArray(s) ? s[0] : "")).join("") || text;
  } catch (_) { return text; }
}

async function translateFields(obj, targetLang) {
  if (targetLang === "en") return obj;
  const [description, treatment, prevention] = await Promise.all([
    obj.description ? gtranslate(obj.description, targetLang) : Promise.resolve(""),
    obj.treatment   ? gtranslate(obj.treatment, targetLang)   : Promise.resolve(""),
    obj.prevention  ? gtranslate(obj.prevention, targetLang)  : Promise.resolve(""),
  ]);
  return { ...obj, description, treatment, prevention };
}

function pickFallback(crop, temperature, humidity, rainfall) {
  const temp = parseFloat(temperature) || 28;
  const hum  = parseFloat(humidity)    || 70;
  const rain = parseFloat(rainfall)    || 0;

  const db = {
    rice: [
      { disease_name: "Rice Blast", severity: "moderate", confidence: 0.55,
        description: "Rice blast (Magnaporthe oryzae) causes diamond-shaped grey lesions with brown borders on leaves, and neck rot that produces empty panicles with no grain.",
        treatment: "Spray Tricyclazole 75WP at 0.6g per litre or Carbendazim 50WP at 1g per litre. Repeat after 10 days.",
        prevention: "Use resistant varieties (IR64, Samba Mahsuri). Avoid excess nitrogen. Treat seed with Carbendazim 2g/kg. Remove infected debris after harvest." },
      { disease_name: "Sheath Blight", severity: "mild", confidence: 0.50,
        description: "Rhizoctonia solani causes oval greenish-grey lesions on leaf sheath that spread upward under dense humid crop conditions.",
        treatment: "Spray Hexaconazole 5SC at 2ml/L or Propiconazole 25EC at 1ml/L. Drain field before spraying.",
        prevention: "Proper plant spacing. Avoid excess nitrogen. Remove crop residues after harvest." },
    ],
    wheat: [
      { disease_name: "Yellow Rust", severity: "moderate", confidence: 0.55,
        description: "Puccinia striiformis causes yellow-orange pustules in neat stripes along leaf length. Favoured by cool humid conditions at 10-15 degrees C.",
        treatment: "Spray Propiconazole 25EC at 1ml/L or Tebuconazole 25.9EC at 1ml/L at first pustule appearance.",
        prevention: "Use resistant varieties (HD 2967, PBW 343). Sow in October-November. Avoid excess nitrogen." },
    ],
    tomato: [
      { disease_name: "Early Blight", severity: "moderate", confidence: 0.55,
        description: "Alternaria solani causes dark brown concentric ring spots with target-board pattern on lower leaves with yellow halos.",
        treatment: "Spray Mancozeb 75WP at 2.5g/L or Chlorothalonil 75WP at 2g/L every 7-10 days. Remove infected lower leaves.",
        prevention: "Avoid overhead irrigation. Mulch soil. Crop rotation for 2-3 years. Remove crop debris." },
      { disease_name: "Tomato Leaf Curl Virus", severity: "severe", confidence: 0.50,
        description: "Whitefly-transmitted viral disease causing upward leaf curl, yellowing, stunted growth, and very poor fruit set.",
        treatment: "No cure for infected plants. Remove and destroy them. Control whitefly with Imidacloprid 17.8SL at 0.25ml/L.",
        prevention: "Virus-resistant varieties (Arka Rakshak). Yellow sticky traps. Reflective silver mulch." },
    ],
    potato: [
      { disease_name: "Late Blight", severity: "severe", confidence: 0.60,
        description: "Phytophthora infestans causes dark water-soaked lesions with white mold on leaf undersides. Spreads extremely fast in cool humid weather.",
        treatment: "EMERGENCY. Spray Cymoxanil + Mancozeb at 3g/L or Metalaxyl + Mancozeb at 2.5g/L immediately. Repeat every 5-7 days.",
        prevention: "Avoid overhead irrigation. Use certified seed tubers. Resistant varieties. Earth up soil over tubers." },
    ],
    cotton: [
      { disease_name: "Cotton Leaf Curl Disease", severity: "severe", confidence: 0.55,
        description: "Whitefly-transmitted viral disease causing upward rolling of leaves and vein thickening. Severely reduces yield.",
        treatment: "No direct cure. Control whitefly urgently: Spiromesifen 22.9SC at 0.75ml/L or Pyriproxyfen 10EC at 0.5ml/L.",
        prevention: "CLCuD-resistant varieties. Early sowing. Yellow sticky traps 10/acre. Crop-free period in off-season." },
    ],
    maize: [
      { disease_name: "Fall Armyworm Damage", severity: "moderate", confidence: 0.55,
        description: "Spodoptera frugiperda causes ragged leaf damage with visible sawdust-like frass in whorls. Larva has inverted Y mark on its head.",
        treatment: "Spray Emamectin benzoate 5SG at 0.4g/L into whorls in the evening. Or Spinetoram 11.7SC at 0.5ml/L.",
        prevention: "Early sowing. Pheromone traps for monitoring. Bt spray at early larval stage. Remove crop residues." },
    ],
    soybean: [
      { disease_name: "Soybean Rust", severity: "moderate", confidence: 0.55,
        description: "Phakopsora pachyrhizi causes orange-brown pustules on leaf undersides. Spreads rapidly in warm humid weather above 75% humidity.",
        treatment: "Spray Tebuconazole 25.9EC at 1ml/L or Hexaconazole 5SC at 2ml/L before 30% canopy closure.",
        prevention: "Tolerant varieties. Early planting. Good air circulation. Remove crop residues." },
    ],
    sugarcane: [
      { disease_name: "Red Rot of Sugarcane", severity: "severe", confidence: 0.55,
        description: "Colletotrichum falcatum causes internal red discoloration of stalks with white patches and a sour fermented smell.",
        treatment: "No cure. Remove and destroy affected stools. Treat seed setts in Carbendazim 0.1% + Dithane M-45 0.25% for 30 minutes.",
        prevention: "Resistant varieties (CoJ 64). Certified disease-free setts. Sterilize cutting tools with 10% bleach between cuts." },
    ],
    groundnut: [
      { disease_name: "Early Leaf Spot", severity: "moderate", confidence: 0.55,
        description: "Cercospora arachidicola causes round dark brown spots on leaves. Severe infection causes defoliation and reduces pod yield significantly.",
        treatment: "Spray Mancozeb 75WP at 2.5g/L or Chlorothalonil 75WP at 2g/L every 10-14 days starting from 30 DAS.",
        prevention: "Proper spacing for air circulation. Remove and destroy infected plant debris. Crop rotation." },
    ],
    onion: [
      { disease_name: "Purple Blotch", severity: "moderate", confidence: 0.55,
        description: "Alternaria porri causes small whitish lesions with purple centers on leaves. Under humid conditions, entire leaves can be destroyed.",
        treatment: "Spray Iprodione + Carbendazim (combination fungicide) or Mancozeb 2.5g/L at 10-day intervals.",
        prevention: "Avoid overhead irrigation. Ensure good air circulation. Crop rotation." },
    ],
    banana: [
      { disease_name: "Sigatoka Leaf Spot", severity: "moderate", confidence: 0.50,
        description: "Mycosphaerella fijiensis causes streaks and spots on banana leaves that turn brown and dry. Reduces photosynthesis and yield.",
        treatment: "Spray Propiconazole 0.1% + sticker every 3 weeks. Remove heavily infected leaves.",
        prevention: "Remove dried and infected leaves regularly. Good drainage. Resistant varieties like Poovan." },
    ],
    other: [
      { disease_name: "Fungal Leaf Spot", severity: "mild", confidence: 0.40,
        description: "Common fungal leaf spots appear as circular spots with defined margins, often with concentric rings or yellow halos. Spread by rain splash and high humidity.",
        treatment: "Spray Mancozeb 75WP at 2.5g/L or Copper oxychloride 50WP at 3g/L every 10-14 days.",
        prevention: "Avoid overhead irrigation. Proper plant spacing. Remove infected material promptly. Crop rotation." },
    ],
  };

  const cropKey = (crop || "other").toLowerCase();
  const list = db[cropKey] || db["other"];
  let chosen = list[0];
  if (list.length > 1) {
    if (hum > 80 || rain > 20) chosen = list[0];
    else if (temp > 33) chosen = list[list.length - 1];
    else chosen = list[Math.floor(Math.random() * list.length)];
  }
  return {
    ...chosen,
    note: "Automated assessment based on crop type and weather only. For accurate visual diagnosis an OpenAI API key is required. Call Kisan Call Centre: 1800-180-1551 (Toll Free)."
  };
}

router.post("/", async (req, res) => {
  const { image, crop, temperature, humidity, rainfall, language = "en" } = req.body;
  if (!image || !crop) return res.status(400).json({ error: "image and crop required" });

  const langName = LANG_NAMES[language] ?? "English";

  if (process.env.OPENAI_API_KEY?.trim() && process.env.OPENAI_API_KEY !== "your_openai_api_key_here") {
    try {
      const { default: OpenAI } = await import("openai");
      const client = new OpenAI({ baseURL: process.env.OPENAI_BASE_URL, apiKey: process.env.OPENAI_API_KEY });
      const wx = [
        temperature != null ? `Temp:${temperature}°C` : null,
        humidity    != null ? `Humidity:${humidity}%` : null,
        rainfall    != null ? `Rain:${rainfall}mm`    : null
      ].filter(Boolean).join(", ");
      const prompt = `Plant pathologist for ${crop}. Analyze this leaf image. ${wx ? `Weather: ${wx}.` : ""} Respond in ${langName}. Return ONLY valid JSON: {"disease_name":"...","severity":"none|mild|moderate|severe","confidence":0.0-1.0,"description":"...","treatment":"...","prevention":"..."}`;
      const r = await client.chat.completions.create({
        model: process.env.OPENAI_MODEL || "gpt-4o-mini",
        messages: [{ role: "user", content: [
          { type: "image_url", image_url: { url: image, detail: "high" } },
          { type: "text", text: prompt }
        ]}],
        max_tokens: 1000,
        response_format: { type: "json_object" },
      });
      const text = r.choices[0]?.message?.content ?? "{}";
      try { return res.json(JSON.parse(text)); }
      catch { return res.json({ disease_name: "Parse Error", severity: "none", confidence: 0, description: "Could not parse AI response.", treatment: "", prevention: "" }); }
    } catch (err) {
      if (!(err?.status === 401 || err?.status === 429 || err?.status === 503))
        return res.status(err?.status >= 400 ? err.status : 500).json({ error: err.message });
    }
  }

  const base = pickFallback(crop, temperature, humidity, rainfall);
  const result = await translateFields(base, language);
  res.json(result);
});

export default router;
