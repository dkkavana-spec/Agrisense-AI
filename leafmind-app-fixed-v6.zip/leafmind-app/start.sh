#!/bin/bash
# LeafMind Quick Start Script
# Starts both backend and frontend in parallel

echo "🌿 Starting LeafMind..."

# Check for .env
if [ ! -f backend/.env ]; then
  cp backend/.env.example backend/.env
  echo "⚠️  Created backend/.env — please add your OPENAI_API_KEY before continuing"
  echo "   Edit backend/.env and then re-run this script"
  exit 1
fi

# Install backend deps if needed
if [ ! -d backend/node_modules ]; then
  echo "📦 Installing backend dependencies..."
  cd backend && npm install && cd ..
fi

# Install frontend deps if needed
if ! python3 -c "import streamlit" 2>/dev/null; then
  echo "📦 Installing frontend dependencies..."
  pip install -r frontend/requirements.txt
fi

echo ""
echo "✅ Starting backend on http://localhost:3001"
echo "✅ Starting Streamlit frontend on http://localhost:8501"
echo "✅ React web app (with voice) also at http://localhost:3001"
echo ""

# Start backend in background
cd backend && npm start &
BACKEND_PID=$!
cd ..

# Wait a moment for backend to start
sleep 2

# Start Streamlit frontend
cd frontend
BACKEND_URL=http://localhost:3001 streamlit run app.py

# Cleanup on exit
kill $BACKEND_PID 2>/dev/null
