import streamlit as st
import requests
import base64
import json
import os
from pathlib import Path

# ── Config ──────────────────────────────────────────────────────────────────
BACKEND_URL = os.environ.get("BACKEND_URL", "http://localhost:3001")

st.set_page_config(
    page_title="LeafMind — AI Plant Disease Diagnosis",
    page_icon="🌿",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ───────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,700&family=Inter:wght@400;500;600&display=swap');

html, body, [class*="css"] { font-family: 'Inter', sans-serif; }
h1, h2, h3 { font-family: 'Fraunces', serif; letter-spacing: -0.02em; }

.stApp { background: linear-gradient(135deg, #faf9f5 0%, #f0f5ec 100%); }

.hero-card {
    background: linear-gradient(135deg, #1a4731, #2d6a4f);
    color: white;
    padding: 2rem;
    border-radius: 1.5rem;
    margin-bottom: 1.5rem;
    box-shadow: 0 20px 60px -20px rgba(26,71,49,0.4);
}
.hero-card h1 { color: white; margin: 0; font-size: 2rem; }
.hero-card p { color: rgba(255,255,255,0.8); margin: 0.5rem 0 0; }

.result-card {
    background: white;
    border-radius: 1.25rem;
    padding: 1.5rem;
    margin: 1rem 0;
    border: 1px solid #e8ede6;
    box-shadow: 0 4px 20px rgba(0,0,0,0.06);
}
.result-card h2 { font-family: 'Fraunces', serif; color: #1a4731; margin-top: 0; }

.severity-none, .severity-mild { background: #dcfce7; color: #15803d; padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.75rem; font-weight: 600; display: inline-block; }
.severity-moderate { background: #fef9c3; color: #854d0e; padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.75rem; font-weight: 600; display: inline-block; }
.severity-severe { background: #fee2e2; color: #dc2626; padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.75rem; font-weight: 600; display: inline-block; }

.chat-user { background: linear-gradient(135deg, #1a4731, #2d6a4f); color: white; padding: 0.75rem 1rem; border-radius: 1rem 1rem 0.25rem 1rem; margin: 0.5rem 0; max-width: 80%; margin-left: auto; }
.chat-bot { background: #f0f5ec; color: #1a2e1a; padding: 0.75rem 1rem; border-radius: 1rem 1rem 1rem 0.25rem; margin: 0.5rem 0; max-width: 80%; border: 1px solid #d8e8d0; }
.chat-bot strong { color: #1a4731; }

.lang-badge { background: #dcfce7; color: #15803d; padding: 0.2rem 0.6rem; border-radius: 9999px; font-size: 0.7rem; font-weight: 600; }

.stButton > button {
    background: linear-gradient(135deg, #1a4731, #2d6a4f) !important;
    color: white !important;
    border: none !important;
    border-radius: 0.75rem !important;
    font-weight: 600 !important;
    padding: 0.6rem 1.5rem !important;
}
.stButton > button:hover { opacity: 0.9 !important; transform: translateY(-1px); }

.voice-btn {
    background: #f0f5ec !important;
    color: #1a4731 !important;
    border: 2px solid #1a4731 !important;
}
</style>
""", unsafe_allow_html=True)

# ── Language config ──────────────────────────────────────────────────────────
LANGUAGES = {
    "en": "English",
    "hi": "हिंदी",
    "kn": "ಕನ್ನಡ",
    "te": "తెలుగు",
    "ta": "தமிழ்",
    "mr": "मराठी",
    "bn": "বাংলা",
    "gu": "ગુજરાતી",
    "pa": "ਪੰਜਾਬੀ",
}

CROPS = ["rice", "wheat", "maize", "tomato", "potato", "cotton", "soybean", "sugarcane", "other"]

SUGGESTED_QUESTIONS = {
    "en": ["What are the symptoms of rice blast disease?", "How do I treat wheat rust?", "How to control aphids organically?", "What is the best fertilizer for tomatoes?"],
    "hi": ["धान के ब्लास्ट रोग के क्या लक्षण हैं?", "गेहूं के रस्ट रोग का उपचार कैसे करें?", "कीड़ों को जैविक तरीके से कैसे नियंत्रित करें?", "टमाटर के लिए सबसे अच्छी खाद क्या है?"],
    "kn": ["ಭತ್ತದ ಬ್ಲಾಸ್ಟ್ ರೋಗದ ಲಕ್ಷಣಗಳೇನು?", "ಗೋಧಿ ತುಕ್ಕು ರೋಗವನ್ನು ಹೇಗೆ ಚಿಕಿತ್ಸೆ ಮಾಡಬೇಕು?", "ಮಾಹು ಕೀಟಗಳನ್ನು ಸಾವಯವ ರೀತಿಯಲ್ಲಿ ನಿಯಂತ್ರಿಸುವುದು ಹೇಗೆ?", "ಟೊಮೇಟೊಗೆ ಉತ್ತಮ ಗೊಬ್ಬರ ಯಾವುದು?"],
    "te": ["వరి బ్లాస్ట్ వ్యాధి లక్షణాలు ఏమిటి?", "గోధుమ నిరోధక వ్యాధిని ఎలా చికిత్స చేయాలి?", "అఫిడ్‌లను సేంద్రియంగా ఎలా నియంత్రించాలి?", "టమాటాకు ఉత్తమ ఎరువు ఏది?"],
    "ta": ["நெல் வெடிப்பு நோயின் அறிகுறிகள் என்ன?", "கோதுமை துரு நோயை எவ்வாறு சிகிச்சை செய்வது?", "அசுவினிகளை இயற்கை முறையில் கட்டுப்படுத்துவது எப்படி?", "தக்காளிக்கு சிறந்த உரம் எது?"],
    "mr": ["भात ब्लास्ट रोगाची लक्षणे काय?", "गव्हाच्या गंज रोगावर उपचार कसे करावे?", "मावा कीड जैविक पद्धतीने नियंत्रण कसे करावे?", "टोमॅटोसाठी सर्वोत्तम खत कोणते?"],
    "bn": ["ধানের ব্লাস্ট রোগের লক্ষণ কী?", "গমের মরিচা রোগের চিকিৎসা কীভাবে করবেন?", "জৈবভাবে এফিড নিয়ন্ত্রণ কীভাবে করবেন?", "টমেটোর জন্য সেরা সার কী?"],
    "gu": ["ડાંગરના બ્લાસ્ટ રોગના લક્ષણો શું છે?", "ઘઉંના ગેરુ રોગની સારવાર કેવી રીતે?", "માહૂ જૈવ રીતે નિયંત્રણ કેવી રીતે?", "ટામેટા માટે શ્રેષ્ઠ ખાતર ક્યું?"],
    "pa": ["ਝੋਨੇ ਦੇ ਬਲਾਸਟ ਰੋਗ ਦੇ ਲੱਛਣ ਕੀ ਹਨ?", "ਕਣਕ ਦੇ ਗੇਰੂ ਰੋਗ ਦਾ ਇਲਾਜ ਕਿਵੇਂ?", "ਮਾਹੂ ਕੀਟ ਜੈਵਿਕ ਤਰੀਕੇ ਨਾਲ ਕੰਟਰੋਲ?", "ਟਮਾਟੇ ਲਈ ਸਭ ਤੋਂ ਵਧੀਆ ਖਾਦ ਕਿਹੜੀ?"],
}

# ── Session state ────────────────────────────────────────────────────────────
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []
if "diag_result" not in st.session_state:
    st.session_state.diag_result = None
if "diag_history" not in st.session_state:
    st.session_state.diag_history = []
if "page" not in st.session_state:
    st.session_state.page = "🌿 Dashboard"
if "lang" not in st.session_state:
    st.session_state.lang = "en"

# ── Helpers ──────────────────────────────────────────────────────────────────
def api_chat(messages: list, language: str) -> str:
    try:
        r = requests.post(
            f"{BACKEND_URL}/api/chat",
            json={"messages": messages, "language": language},
            timeout=30,
        )
        r.raise_for_status()
        return r.json().get("reply", "No response received.")
    except Exception as e:
        return f"⚠️ Could not reach the backend: {e}"


def api_diagnose(image_b64: str, crop: str, temp, hum, rain, language: str) -> dict:
    try:
        r = requests.post(
            f"{BACKEND_URL}/api/diagnose",
            json={
                "image": image_b64,
                "crop": crop,
                "temperature": temp,
                "humidity": hum,
                "rainfall": rain,
                "language": language,
            },
            timeout=45,
        )
        r.raise_for_status()
        return r.json()
    except Exception as e:
        return {"error": str(e)}


def severity_badge(sev: str) -> str:
    cls = f"severity-{sev}" if sev in ("none", "mild", "moderate", "severe") else "severity-none"
    return f'<span class="{cls}">Severity: {sev.upper()}</span>'


# ── Sidebar ──────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## 🌿 LeafMind")
    st.markdown("*AI Plant Disease Diagnosis*")
    st.divider()

    st.session_state.page = st.radio(
        "Navigate",
        ["🌿 Dashboard", "🔬 Diagnose", "💬 AgroBot", "📋 History"],
        index=["🌿 Dashboard", "🔬 Diagnose", "💬 AgroBot", "📋 History"].index(st.session_state.page),
    )

    st.divider()
    st.markdown("**🌍 Language**")
    lang_label = st.selectbox(
        "Response language",
        options=list(LANGUAGES.keys()),
        format_func=lambda c: LANGUAGES[c],
        index=list(LANGUAGES.keys()).index(st.session_state.lang),
        label_visibility="collapsed",
    )
    st.session_state.lang = lang_label
    st.markdown(f'<span class="lang-badge">9 languages supported</span>', unsafe_allow_html=True)

    st.divider()
    st.markdown("**Backend**")
    st.code(BACKEND_URL, language=None)
    if st.button("Test connection"):
        try:
            r = requests.get(f"{BACKEND_URL}/api/healthz", timeout=5)
            st.success("✅ Connected") if r.ok else st.error("❌ Backend error")
        except:
            st.error("❌ Cannot reach backend")

# ── DASHBOARD page ───────────────────────────────────────────────────────────
if st.session_state.page == "🌿 Dashboard":
    st.markdown("""
    <div class="hero-card">
        <h1>🌿 LeafMind</h1>
        <p>AI plant disease diagnosis for every farmer · 9 Indian languages</p>
    </div>
    """, unsafe_allow_html=True)

    col1, col2, col3 = st.columns(3)
    history = st.session_state.diag_history
    with col1:
        st.metric("Total Scans", len(history))
    with col2:
        severe = sum(1 for d in history if d.get("severity") == "severe")
        st.metric("Severe Cases", severe)
    with col3:
        healthy = sum(1 for d in history if d.get("disease_name", "").lower() == "healthy")
        st.metric("Healthy Results", healthy)

    st.divider()
    col_d, col_c = st.columns(2)
    with col_d:
        if st.button("🔬 New Diagnosis", use_container_width=True):
            st.session_state.page = "🔬 Diagnose"
            st.rerun()
    with col_c:
        if st.button("💬 Ask AgroBot", use_container_width=True):
            st.session_state.page = "💬 AgroBot"
            st.rerun()

    if history:
        st.subheader("Recent diagnoses")
        for d in reversed(history[-6:]):
            with st.expander(f"**{d.get('disease_name','Unknown')}** — {d.get('crop','').title()} ({d.get('created_at','')})"):
                st.markdown(severity_badge(d.get("severity", "none")), unsafe_allow_html=True)
                if d.get("description"):
                    st.write(d["description"])

    st.divider()
    st.markdown("**Supported languages:**")
    lang_str = " · ".join(LANGUAGES.values())
    st.markdown(f"<p style='color:#2d6a4f;font-weight:600'>{lang_str}</p>", unsafe_allow_html=True)


# ── DIAGNOSE page ────────────────────────────────────────────────────────────
elif st.session_state.page == "🔬 Diagnose":
    st.title("🔬 Diagnose a Crop")
    st.caption("Upload a clear photo of the affected leaf for AI-powered disease diagnosis.")

    col_form, col_result = st.columns([1, 1], gap="large")

    with col_form:
        uploaded = st.file_uploader("📷 Upload leaf photo", type=["jpg", "jpeg", "png", "webp"])
        if uploaded:
            st.image(uploaded, caption="Uploaded leaf", use_container_width=True)

        crop = st.selectbox("🌾 Crop type", CROPS, format_func=str.title)

        with st.expander("🌤 Weather context (optional, improves accuracy)"):
            temp = st.number_input("Temperature (°C)", min_value=-10.0, max_value=55.0, value=28.0, step=0.5)
            hum = st.number_input("Humidity (%)", min_value=0, max_value=100, value=70)
            rain = st.number_input("Rainfall last 7 days (mm)", min_value=0.0, value=0.0, step=0.5)

        lang_diag = st.selectbox(
            "📢 Result language",
            list(LANGUAGES.keys()),
            format_func=lambda c: LANGUAGES[c],
            index=list(LANGUAGES.keys()).index(st.session_state.lang),
        )

        run_btn = st.button("✨ Run Diagnosis", use_container_width=True, disabled=uploaded is None)

    with col_result:
        if run_btn and uploaded:
            raw = uploaded.read()
            b64 = "data:" + uploaded.type + ";base64," + base64.b64encode(raw).decode()
            with st.spinner("Analyzing leaf… this takes a few seconds"):
                result = api_diagnose(b64, crop, temp, hum, rain, lang_diag)

            if "error" in result:
                st.error(f"Diagnosis failed: {result['error']}")
            else:
                st.session_state.diag_result = result
                import datetime
                result["crop"] = crop
                result["created_at"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
                st.session_state.diag_history.append(result)
                st.success("Diagnosis complete!")

        if st.session_state.diag_result:
            r = st.session_state.diag_result
            st.markdown(f"""
            <div class="result-card">
                <h2>{r.get('disease_name', 'Unknown')}</h2>
                {severity_badge(r.get('severity', 'none'))}
                <p style='margin-top:0.5rem;color:#666;font-size:0.85rem'>Confidence: {int((r.get('confidence') or 0) * 100)}%</p>
            </div>
            """, unsafe_allow_html=True)

            if r.get("description"):
                with st.expander("📋 Description", expanded=True):
                    st.write(r["description"])
            if r.get("treatment"):
                with st.expander("💊 Treatment", expanded=True):
                    st.write(r["treatment"])
            if r.get("prevention"):
                with st.expander("🛡 Prevention & Care"):
                    st.write(r["prevention"])

            if r.get("severity") == "severe":
                st.warning("⚠️ High severity — consider consulting a local agricultural extension officer.")
        else:
            st.info("Upload a leaf photo and click **Run Diagnosis** to get started.")


# ── AGROBOT page ─────────────────────────────────────────────────────────────
elif st.session_state.page == "💬 AgroBot":
    st.title("💬 AgroBot")
    st.caption(f"AI farming assistant · responding in **{LANGUAGES[st.session_state.lang]}** · ask about diseases, pests, fertilizers, irrigation")

    # Voice input section
    st.markdown("### 🎤 Voice Input")
    st.info("🎤 Voice input is available in the browser — use the **web app** (React frontend) for full voice support, or type your question below.")

    # Suggested questions
    if not st.session_state.chat_history:
        st.markdown("**Suggested questions:**")
        suggestions = SUGGESTED_QUESTIONS.get(st.session_state.lang, SUGGESTED_QUESTIONS["en"])
        cols = st.columns(2)
        for i, q in enumerate(suggestions):
            with cols[i % 2]:
                if st.button(q, key=f"sq_{i}", use_container_width=True):
                    st.session_state.chat_history.append({"role": "user", "content": q})
                    with st.spinner("AgroBot is thinking…"):
                        msgs = [{"role": m["role"], "content": m["content"]} for m in st.session_state.chat_history]
                        reply = api_chat(msgs, st.session_state.lang)
                    st.session_state.chat_history.append({"role": "assistant", "content": reply})
                    st.rerun()

    # Chat history
    for msg in st.session_state.chat_history:
        if msg["role"] == "user":
            st.markdown(f'<div class="chat-user">👤 {msg["content"]}</div>', unsafe_allow_html=True)
        else:
            st.markdown(f'<div class="chat-bot">🤖 <strong>AgroBot:</strong><br>{msg["content"]}</div>', unsafe_allow_html=True)

    st.divider()

    # Input
    with st.form("chat_form", clear_on_submit=True):
        col_inp, col_btn = st.columns([4, 1])
        with col_inp:
            user_input = st.text_area(
                "Your question",
                placeholder="Ask about crop diseases, pests, fertilizers…",
                label_visibility="collapsed",
                height=80,
            )
        with col_btn:
            submitted = st.form_submit_button("Send 📤", use_container_width=True)

    if submitted and user_input.strip():
        st.session_state.chat_history.append({"role": "user", "content": user_input.strip()})
        with st.spinner(f"AgroBot is thinking in {LANGUAGES[st.session_state.lang]}…"):
            msgs = [{"role": m["role"], "content": m["content"]} for m in st.session_state.chat_history]
            reply = api_chat(msgs, st.session_state.lang)
        st.session_state.chat_history.append({"role": "assistant", "content": reply})
        st.rerun()

    if st.session_state.chat_history:
        if st.button("🗑 Clear chat"):
            st.session_state.chat_history = []
            st.rerun()


# ── HISTORY page ──────────────────────────────────────────────────────────────
elif st.session_state.page == "📋 History":
    st.title("📋 Diagnosis History")
    st.caption("All diagnoses run this session.")

    if not st.session_state.diag_history:
        st.info("No diagnoses yet. Go to **🔬 Diagnose** to run your first scan.")
    else:
        for i, d in enumerate(reversed(st.session_state.diag_history)):
            with st.expander(
                f"**{d.get('disease_name', 'Unknown')}** · {d.get('crop', '').title()} · {d.get('created_at', '')}",
                expanded=(i == 0),
            ):
                st.markdown(severity_badge(d.get("severity", "none")), unsafe_allow_html=True)
                conf = d.get("confidence")
                if conf is not None:
                    st.caption(f"Confidence: {int(conf * 100)}%")
                if d.get("description"):
                    st.markdown("**Description**")
                    st.write(d["description"])
                if d.get("treatment"):
                    st.markdown("**Treatment**")
                    st.write(d["treatment"])
                if d.get("prevention"):
                    st.markdown("**Prevention**")
                    st.write(d["prevention"])
