# LeafMind — AI Plant Disease Diagnosis

AI-powered plant disease diagnosis for Indian farmers in 9 languages:
**English · हिंदी · ಕನ್ನಡ · తెలుగు · தமிழ் · मराठी · বাংলা · ગુજરાતી · ਪੰਜਾਬੀ**

---

## Project Structure

```
leafmind-app/
├── start.bat          ← Windows launcher (double-click to run)
├── start.sh           ← Mac / Linux launcher
│
├── frontend/          ← Python Streamlit app (pure Python UI)
│   ├── app.py
│   ├── requirements.txt
│   └── .streamlit/config.toml
│
└── backend/           ← Node.js Express API + React web app
    ├── src/
    │   ├── index.js
    │   └── routes/
    │       ├── chat.js       ← AgroBot multilingual chat API
    │       └── diagnose.js   ← Leaf disease diagnosis API
    ├── public/
    │   ├── index.html        ← React frontend (no build needed)
    │   ├── app.jsx           ← Full React app with voice input
    │   ├── manifest.json     ← PWA manifest (install on phone)
    │   └── sw.js             ← Service worker (offline support)
    ├── package.json
    └── .env.example
```

---

## Quick Start

### Windows

1. Install **Node.js** from https://nodejs.org (LTS version)
2. Install **Python** from https://python.org (3.9 or newer)
3. Double-click **`start.bat`**
   - On first run it will open `backend\.env` in Notepad — paste your OpenAI API key and save
   - It installs all dependencies and opens your browser automatically

### Mac / Linux

```bash
cd backend
cp .env.example .env
# Edit .env and add your OpenAI API key

cd ..
chmod +x start.sh
./start.sh
```

### Manual start (any OS)

**Backend (Node.js):**
```bash
cd backend
# Windows:
copy .env.example .env
# Mac/Linux:
cp .env.example .env

npm install
node src/index.js
```

**Frontend (Python Streamlit):**
```bash
cd frontend
pip install -r requirements.txt
python -m streamlit run app.py
```

---

## Access the App

| Interface        | URL                       | Notes                        |
|------------------|---------------------------|------------------------------|
| React web app    | http://localhost:3001     | Voice input, PWA install     |
| Streamlit UI     | http://localhost:8501     | Python-based UI              |
| API health check | http://localhost:3001/api/healthz | Backend status      |

---

## Features

### 🔬 Diagnose
- Upload a leaf photo from your phone or computer
- Select crop type (rice, wheat, maize, tomato, potato, cotton, etc.)
- Add weather context (temperature, humidity, rainfall) for better accuracy
- Get AI diagnosis: disease name, severity, treatment steps, prevention
- Results in your chosen language

### 💬 AgroBot Chat
- Ask any farming question in your language
- **Voice input** (mic button) — speak your question, it transcribes automatically
- Expert answers about diseases, pests, fertilizers, irrigation, organic farming

### 📋 History
- All diagnoses saved locally in browser
- Tap any card to view full report

### 📲 PWA — Install on Phone
The React web app supports installation as a Progressive Web App:
- Open `http://<your-pc-ip>:3001` on your phone's browser
- Tap **"Install LeafMind"** when the banner appears (or use browser menu → Add to Home Screen)
- Works offline for browsing history; AI features need internet

---

## Configuration

### Backend `backend\.env` (Windows) / `backend/.env` (Mac/Linux)

```env
OPENAI_API_KEY=sk-...          # Your OpenAI API key
OPENAI_MODEL=gpt-4o-mini       # Model (must support vision for diagnose)
PORT=3001                       # Server port
```

### Frontend environment variable

```
BACKEND_URL=http://localhost:3001   # Where the Node.js backend is running
```

---

## Requirements

### Backend
- Node.js 18 or newer
- npm (comes with Node.js)
- OpenAI API key (with vision access for diagnose)

### Frontend (Python)
- Python 3.9 or newer
- pip

---

## Voice Input

Voice input is available in the **React web app** (`http://localhost:3001`).

Supported browsers:
- Chrome, Edge (Windows/Mac/Android)
- Safari (Mac/iOS)

**How it works:**
1. Open AgroBot tab in the React web app
2. Tap the 🎤 mic button
3. Speak in your language — text appears automatically
4. Press Send

Supported locales: en-IN, hi-IN, kn-IN, te-IN, ta-IN, mr-IN, bn-IN, gu-IN, pa-IN

---

## API Reference

### POST /api/chat
```json
{
  "messages": [{"role": "user", "content": "ಭತ್ತದ ರೋಗ ಏನು?"}],
  "language": "kn"
}
```
Returns: `{ "reply": "ಭತ್ತದ ..." }`

### POST /api/diagnose
```json
{
  "image": "data:image/jpeg;base64,...",
  "crop": "rice",
  "temperature": 28,
  "humidity": 75,
  "rainfall": 20,
  "language": "kn"
}
```

---

## Language Codes

| Code | Language  |
|------|-----------|
| en   | English   |
| hi   | हिंदी      |
| kn   | ಕನ್ನಡ     |
| te   | తెలుగు    |
| ta   | தமிழ்     |
| mr   | मराठी     |
| bn   | বাংলা     |
| gu   | ગુજરાતી   |
| pa   | ਪੰਜਾਬੀ    |
